-- Fertiliv actual production schema export
-- Exported UTC: 2026-09-30T19:46:11.585Z
-- Source database name only; credentials are intentionally excluded.
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

-- BASE TABLE: __drizzle_migrations
CREATE TABLE `__drizzle_migrations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `hash` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` bigint DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=241385;

-- BASE TABLE: ai_import_drafts
CREATE TABLE `ai_import_drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `draftKey` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` int NOT NULL,
  `step` enum('input','preview') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'input',
  `pasteText` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploadedFiles` json DEFAULT NULL,
  `rows` json DEFAULT NULL,
  `selectedIds` json DEFAULT NULL,
  `matchOverrides` json DEFAULT NULL,
  `manualMatchAliasOptIn` json DEFAULT NULL,
  `lastSavedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `ai_import_drafts_draftKey_userId_idx` (`draftKey`,`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=540001;

-- BASE TABLE: ai_usage_attempts
CREATE TABLE `ai_usage_attempts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `attemptId` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logicalRequestId` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `workloadId` varchar(96) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(160) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attemptNumber` int NOT NULL,
  `status` enum('started','succeeded','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'started',
  `latencyMs` int DEFAULT NULL,
  `inputTokens` bigint DEFAULT NULL,
  `outputTokens` bigint DEFAULT NULL,
  `cachedTokens` bigint DEFAULT NULL,
  `totalTokens` bigint DEFAULT NULL,
  `nonTokenUnit` varchar(48) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nonTokenQuantity` decimal(14,3) DEFAULT NULL,
  `providerUsageAvailable` tinyint(1) NOT NULL DEFAULT '0',
  `failureCategory` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `completedAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `ai_usage_attempts_attempt_id_unique` (`attemptId`),
  KEY `idx_ai_usage_attempts_logical_request` (`logicalRequestId`,`attemptNumber`),
  KEY `idx_ai_usage_attempts_provider_model_created` (`provider`,`model`,`createdAt`),
  KEY `idx_ai_usage_attempts_workload_created` (`workloadId`,`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2370001;

-- BASE TABLE: ai_usage_requests
CREATE TABLE `ai_usage_requests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `logicalRequestId` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `workloadId` varchar(96) COLLATE utf8mb4_unicode_ci NOT NULL,
  `configurationScope` varchar(96) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'platform_default',
  `status` enum('started','succeeded','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'started',
  `attemptCount` int NOT NULL DEFAULT '0',
  `fallbackUsed` tinyint(1) NOT NULL DEFAULT '0',
  `totalLatencyMs` int DEFAULT NULL,
  `inputTokens` bigint DEFAULT NULL,
  `outputTokens` bigint DEFAULT NULL,
  `cachedTokens` bigint DEFAULT NULL,
  `totalTokens` bigint DEFAULT NULL,
  `nonTokenUnit` varchar(48) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nonTokenQuantity` decimal(14,3) DEFAULT NULL,
  `estimatedCost` decimal(18,8) DEFAULT NULL,
  `providerReportedCost` decimal(18,8) DEFAULT NULL,
  `costCurrency` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `failureCategory` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `completedAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `ai_usage_requests_logical_request_id_unique` (`logicalRequestId`),
  KEY `idx_ai_usage_requests_workload_created` (`workloadId`,`createdAt`),
  KEY `idx_ai_usage_requests_status_created` (`status`,`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2370001;

-- BASE TABLE: appointment_activity_log
CREATE TABLE `appointment_activity_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `appointmentId` int NOT NULL,
  `userId` int NOT NULL,
  `action` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `oldValue` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `newValue` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=3450001;

-- BASE TABLE: appointment_communication_deliveries
CREATE TABLE `appointment_communication_deliveries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `appointmentId` int NOT NULL,
  `sendGroupId` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `communicationType` enum('manual_appointment_details') COLLATE utf8mb4_unicode_ci NOT NULL,
  `channel` enum('email') COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipientEmail` varchar(320) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipientType` enum('patient','lead','partner','additional') COLLATE utf8mb4_unicode_ci NOT NULL,
  `profileLanguage` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `localeFallbackUsed` tinyint(1) NOT NULL DEFAULT '0',
  `templateKey` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `templateVersion` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sentByUserId` int NOT NULL,
  `deliveryStatus` enum('sent','failed') COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerMessageId` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `failureClassification` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `failureCode` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sentAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=600001;

-- BASE TABLE: appointment_reminder_deliveries
CREATE TABLE `appointment_reminder_deliveries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `deliveryKey` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `appointmentId` int NOT NULL,
  `recipientKey` varchar(96) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipientType` enum('patient','lead') COLLATE utf8mb4_unicode_ci NOT NULL,
  `channel` enum('email') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'email',
  `scheduleRevision` int NOT NULL,
  `offsetMinutes` int NOT NULL,
  `dueAt` timestamp NOT NULL,
  `status` enum('scheduled','claimed','dispatching','retry_pending','sent','failed','skipped','invalidated') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'scheduled',
  `nextAttemptAt` timestamp NULL DEFAULT NULL,
  `claimedAt` timestamp NULL DEFAULT NULL,
  `claimToken` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `claimExpiresAt` timestamp NULL DEFAULT NULL,
  `dispatchingAt` timestamp NULL DEFAULT NULL,
  `invalidatedAt` timestamp NULL DEFAULT NULL,
  `invalidationReason` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `skippedReason` varchar(96) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sentAt` timestamp NULL DEFAULT NULL,
  `failedAt` timestamp NULL DEFAULT NULL,
  `recipientEmail` varchar(320) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profileLanguage` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deliveredLanguage` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `localeFallbackUsed` tinyint(1) NOT NULL DEFAULT '0',
  `templateKey` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `templateVersion` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerMessageId` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attemptCount` int NOT NULL DEFAULT '0',
  `lastFailureClassification` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastFailureCode` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `appointment_reminder_deliveries_delivery_key_uq` (`deliveryKey`),
  UNIQUE KEY `appointment_reminder_deliveries_business_identity_uq` (`appointmentId`,`recipientKey`,`channel`,`offsetMinutes`,`scheduleRevision`),
  KEY `appointment_reminder_deliveries_due_processing_ix` (`status`,`nextAttemptAt`,`dueAt`),
  KEY `appointment_reminder_deliveries_appointment_revision_ix` (`appointmentId`,`scheduleRevision`),
  KEY `appointment_reminder_deliveries_claim_expiry_ix` (`claimExpiresAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=390001;

-- BASE TABLE: appointment_reminder_delivery_attempts
CREATE TABLE `appointment_reminder_delivery_attempts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reminderDeliveryId` int NOT NULL,
  `attemptNumber` int NOT NULL,
  `idempotencyKey` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `outcome` enum('sent','retryable_failure','permanent_failure','skipped_recipient_unavailable','invalidated_before_send') COLLATE utf8mb4_unicode_ci NOT NULL,
  `attemptedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `completedAt` timestamp NULL DEFAULT NULL,
  `recipientEmail` varchar(320) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profileLanguage` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deliveredLanguage` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `localeFallbackUsed` tinyint(1) NOT NULL DEFAULT '0',
  `providerMessageId` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `failureClassification` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `failureCode` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `appointment_reminder_delivery_attempts_delivery_number_uq` (`reminderDeliveryId`,`attemptNumber`),
  KEY `appointment_reminder_delivery_attempts_delivery_ix` (`reminderDeliveryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- BASE TABLE: appointment_reschedule_events
CREATE TABLE `appointment_reschedule_events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `appointmentId` int NOT NULL,
  `appointmentCode` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `patientId` int DEFAULT NULL,
  `leadId` int DEFAULT NULL,
  `timeOffId` int DEFAULT NULL,
  `oldStart` timestamp NOT NULL,
  `oldEnd` timestamp NOT NULL,
  `newStart` timestamp NOT NULL,
  `newEnd` timestamp NOT NULL,
  `actorId` int NOT NULL,
  `source` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `executedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `exceptionReason` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `idx_appointment_reschedule_events_appointment` (`appointmentId`),
  KEY `idx_appointment_reschedule_events_time_off` (`timeOffId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=480001;

-- BASE TABLE: appointments
CREATE TABLE `appointments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patientId` int DEFAULT NULL,
  `doctorId` int DEFAULT NULL,
  `serviceId` int DEFAULT NULL,
  `staffId` int DEFAULT NULL,
  `title` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `appointmentDate` timestamp NOT NULL,
  `endDate` timestamp NULL DEFAULT NULL,
  `duration` int DEFAULT '30',
  `type` enum('consultation','follow_up','procedure','lab','radiology','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'consultation',
  `status` enum('upcoming','confirmed','completed','cancelled','no_show','rescheduled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'upcoming',
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancellationReason` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reminderSent` tinyint(1) DEFAULT '0',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `leadId` int DEFAULT NULL,
  `hostUserId` int DEFAULT NULL,
  `appointmentType` enum('in-clinic','online','external') COLLATE utf8mb4_unicode_ci DEFAULT 'in-clinic',
  `purpose` enum('sales-consultation','medical-consultation','follow-up','procedure','external-test') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meetingLink` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `partnerClinicId` int DEFAULT NULL,
  `externalLocation` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `availabilityOverrideReason` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `availabilityOverrideById` int DEFAULT NULL,
  `availabilityOverrideAt` timestamp NULL DEFAULT NULL,
  `availabilityOverrideTimeOffId` int DEFAULT NULL,
  `appointmentScheduleRevision` int NOT NULL DEFAULT '1',
  `googleReminderMode` enum('calendar_default','custom') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'calendar_default',
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `idx_appointments_code` (`code`),
  KEY `idx_appointments_availabilityOverrideTimeOffId` (`availabilityOverrideTimeOffId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1830001;

-- BASE TABLE: audit_logs
CREATE TABLE `audit_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int DEFAULT NULL,
  `userName` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `userRole` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` enum('auth','patient','lead','appointment','medical_note','user_management','navigation','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'other',
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recordId` int DEFAULT NULL,
  `recordType` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `page` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `durationSeconds` int DEFAULT NULL,
  `ipAddress` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=45930001;

-- BASE TABLE: case_comments
CREATE TABLE `case_comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `leadId` int DEFAULT NULL,
  `patientId` int DEFAULT NULL,
  `authorId` int NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `isSystemEvent` tinyint(1) NOT NULL DEFAULT '0',
  `visibility` enum('all','doctor_only','staff_only') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'all',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=120001;

-- BASE TABLE: case_participants
CREATE TABLE `case_participants` (
  `id` int NOT NULL AUTO_INCREMENT,
  `caseId` int NOT NULL,
  `leadId` int DEFAULT NULL,
  `patientId` int DEFAULT NULL,
  `role` enum('primary_female','primary_male','donor','surrogate','other') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- BASE TABLE: clinic_info
CREATE TABLE `clinic_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nameEn` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nameAr` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nameTr` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sloganEn` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sloganAr` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sloganTr` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addressEn` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addressAr` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addressTr` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bioEn` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bioAr` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bioTr` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mapsLink` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logoEnLightKey` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logoEnDarkKey` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logoArLightKey` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logoArDarkKey` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stampKey` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int DEFAULT NULL,
  `defaultWeeklySchedule` json DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=30002;

-- BASE TABLE: clinic_tags
CREATE TABLE `clinic_tags` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#6366f1',
  `createdByUserId` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=120001;

-- BASE TABLE: code_sequences
CREATE TABLE `code_sequences` (
  `entity_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_number` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`entity_type`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- BASE TABLE: communication_media_access_audits
CREATE TABLE `communication_media_access_audits` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mediaAssetId` int NOT NULL,
  `conversationId` int NOT NULL,
  `actorId` int NOT NULL,
  `action` enum('open','download','denied') COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `communication_media_access_audits_asset_ix` (`mediaAssetId`,`createdAt`),
  KEY `communication_media_access_audits_actor_ix` (`actorId`,`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1200001;

-- BASE TABLE: communication_media_assets
CREATE TABLE `communication_media_assets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `conversationId` int NOT NULL,
  `normalizedMediaId` int DEFAULT NULL,
  `channelKind` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `storageKey` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `encryptedAtRest` tinyint(1) NOT NULL DEFAULT '1',
  `encryptionVersion` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'storage-managed-v1',
  `mediaType` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mimeType` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filename` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sha256` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accessState` enum('available','quarantined','deleted') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'available',
  `retentionUntil` timestamp NULL DEFAULT NULL,
  `createdById` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `communication_media_assets_conversation_ix` (`conversationId`,`createdAt`),
  KEY `communication_media_assets_retention_ix` (`accessState`,`retentionUntil`),
  UNIQUE KEY `storageKey` (`storageKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=150001;

-- BASE TABLE: conflict_resolution_log
CREATE TABLE `conflict_resolution_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `requestId` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `leadId` int NOT NULL,
  `patientId` int NOT NULL,
  `resolvedBy` int NOT NULL,
  `newIntakeId` int DEFAULT NULL,
  `docHandling` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `newIntakeMode` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `archivedDocs` json DEFAULT NULL,
  `deletedDocs` json DEFAULT NULL,
  `storagePendingDocs` json DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `conflict_resolution_log_requestId_unique` (`requestId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=30001;

-- BASE TABLE: credit_transactions
CREATE TABLE `credit_transactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patientId` int NOT NULL,
  `currency` enum('USD','EUR','GBP','TRY','SAR','AED','AUD') COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `type` enum('overpayment','applied_to_invoice','applied_credit_reversal','credit_payout','refund_deduction','manual_adjustment') COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoiceId` int DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recordedById` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `financialScope` enum('production','test') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'production',
  `originPaymentId` int DEFAULT NULL,
  `originInvoiceId` int DEFAULT NULL,
  `sourceCreditTransactionId` int DEFAULT NULL,
  `settlementId` int DEFAULT NULL,
  `originPaymentMethod` enum('cash','credit_card','bank_transfer','insurance','other') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `targetInvoiceCurrency` enum('USD','EUR','GBP','TRY','SAR','AED','AUD') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `targetSettlementAmount` decimal(10,2) DEFAULT NULL,
  `creditConversionRateToInvoice` decimal(20,12) DEFAULT NULL,
  `creditFxEffectiveAt` timestamp NULL DEFAULT NULL,
  `creditFxSource` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sourceCreditAvailableBefore` decimal(10,2) DEFAULT NULL,
  `patientCreditApplicationId` int DEFAULT NULL,
  `patientCreditPayoutId` int DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `idx_credit_transactions_financialScope` (`financialScope`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=810001;

-- BASE TABLE: cycle_medications
CREATE TABLE `cycle_medications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cycleId` int NOT NULL,
  `medicationName` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dose` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frequency` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `route` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `startDate` timestamp NULL DEFAULT NULL,
  `endDate` timestamp NULL DEFAULT NULL,
  `instructions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=180001;

-- BASE TABLE: cycle_monitoring_visits
CREATE TABLE `cycle_monitoring_visits` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cycleId` int NOT NULL,
  `visitDate` timestamp NOT NULL,
  `cycleDay` int DEFAULT NULL,
  `doctorId` int DEFAULT NULL,
  `e2` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lh` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p4` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `endometriumMm` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `folliclesRight` json DEFAULT NULL,
  `folliclesLeft` json DEFAULT NULL,
  `fshDose` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hmgDose` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gnrhaDose` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `antagonistDose` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ccLetrDose` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hcgDose` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sexualAbstinence` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=150001;

-- BASE TABLE: cycle_outcomes
CREATE TABLE `cycle_outcomes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cycleId` int NOT NULL,
  `totalOocytes` int DEFAULT NULL,
  `matureOocytes` int DEFAULT NULL,
  `fertilized` int DEFAULT NULL,
  `transferred` int DEFAULT NULL,
  `cryopreserved` int DEFAULT NULL,
  `embryoQuality` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hcgLevel` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pregnancyTestDate` timestamp NULL DEFAULT NULL,
  `result` enum('positive','negative','biochemical','clinical','ongoing','delivered','miscarriage','pending') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `blastocystCount` int DEFAULT NULL,
  `triggerDate` timestamp NULL DEFAULT NULL,
  `opuDate` timestamp NULL DEFAULT NULL,
  `transferDate` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `cycleId` (`cycleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=60001;

-- BASE TABLE: doctor_review_requests
CREATE TABLE `doctor_review_requests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `leadId` int DEFAULT NULL,
  `patientId` int DEFAULT NULL,
  `doctorId` int NOT NULL,
  `requestedById` int NOT NULL,
  `status` enum('pending','in_review','plan_ready') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `requestedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reviewStartedAt` timestamp NULL DEFAULT NULL,
  `planReadyAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=120001;

-- BASE TABLE: doctor_sub_specializations
CREATE TABLE `doctor_sub_specializations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `doctorId` int NOT NULL,
  `subSpecializationId` int NOT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=180001;

-- BASE TABLE: doctors
CREATE TABLE `doctors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `specialty` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `licenseNumber` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `consultationFee` decimal(10,2) DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `title` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `firstName` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secondName` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thirdName` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `specializationId` int DEFAULT NULL,
  `avatarUrl` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stampUrl` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `idx_doctors_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=60001;

-- BASE TABLE: document_translations
CREATE TABLE `document_translations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patientId` int NOT NULL,
  `labResultId` int DEFAULT NULL,
  `originalFileUrl` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `originalFileName` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `originalLanguage` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `targetLanguage` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `translatedText` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extractedText` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','processing','completed','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `errorMessage` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `translatedById` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `leadDocumentId` int DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `fk_doc_translations_lead_doc` (`leadDocumentId`),
  CONSTRAINT `fk_doc_translations_lead_doc` FOREIGN KEY (`leadDocumentId`) REFERENCES `lead_documents` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=690001;

-- BASE TABLE: draft_sessions
CREATE TABLE `draft_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `draftSessionId` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `leadId` int DEFAULT NULL,
  `patientId` int DEFAULT NULL,
  `intakeId` int DEFAULT NULL,
  `activeWriterToken` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `writerLeaseExpiresAt` timestamp NOT NULL,
  `lastMeaningfulActivityAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdBy` int NOT NULL,
  `status` enum('active','saved','cancelled','expired') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `pendingExpiresAt` timestamp NULL DEFAULT NULL,
  `savedAt` timestamp NULL DEFAULT NULL,
  `canceledAt` timestamp NULL DEFAULT NULL,
  `canceledBy` int DEFAULT NULL,
  `expiredAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `draft_sessions_draftSessionId_unique` (`draftSessionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2070001;

-- BASE TABLE: dropdown_options
CREATE TABLE `dropdown_options` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldKey` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sortOrder` int NOT NULL DEFAULT '0',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `group_label` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=120001;

-- BASE TABLE: exchange_rates
CREATE TABLE `exchange_rates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `baseCurrency` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetCurrency` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` decimal(18,8) NOT NULL,
  `sourceProvider` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rateDate` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fetchedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `isManualOverride` tinyint(1) NOT NULL DEFAULT '0',
  `overriddenBy` int DEFAULT NULL,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `uq_currency_pair` (`baseCurrency`,`targetCurrency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1740001;

-- BASE TABLE: external_report_processing_runs
CREATE TABLE `external_report_processing_runs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reportId` int NOT NULL,
  `sourceRevisionId` int DEFAULT NULL,
  `processingGoal` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requestedTargetLanguage` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resolvedOutputLanguage` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `processedDocumentVersion` int DEFAULT NULL,
  `processingStatus` enum('processed','reviewed','finalized') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'processed',
  `processedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reviewedAt` timestamp NULL DEFAULT NULL,
  `reviewedById` int DEFAULT NULL,
  `finalizedAt` timestamp NULL DEFAULT NULL,
  `finalizedById` int DEFAULT NULL,
  `createdById` int DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `external_report_processing_run_report_idx` (`reportId`),
  KEY `external_report_processing_run_source_idx` (`sourceRevisionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=300001;

-- BASE TABLE: external_report_source_revisions
CREATE TABLE `external_report_source_revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reportId` int NOT NULL,
  `revisionNumber` int NOT NULL,
  `sourceText` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inputMethod` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sourceLanguage` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sourceAssetRefs` json DEFAULT NULL,
  `sourceHash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `correctionReason` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `capturedById` int DEFAULT NULL,
  `capturedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `external_report_source_revision_unique` (`reportId`,`revisionNumber`),
  KEY `external_report_source_revision_report_idx` (`reportId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=300001;

-- BASE TABLE: external_reports
CREATE TABLE `external_reports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patientId` int NOT NULL,
  `reportRef` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sourceOrganization` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportType` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportDate` timestamp NULL DEFAULT NULL,
  `originalContent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `processedContent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `processingNote` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'translated',
  `language` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'en',
  `originalFiles` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('draft','final') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `createdById` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `processingGoal` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `requestedTargetLanguage` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resolvedOutputLanguage` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `processedDocumentJson` json DEFAULT NULL,
  `processedDocumentVersion` int DEFAULT NULL,
  `activeSourceRevisionId` int DEFAULT NULL,
  `processingRepresentation` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `v2SubmissionKey` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `v2Metadata` json DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `external_reports_v2_submission_key_unique` (`v2SubmissionKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=570001;

-- BASE TABLE: extraction_attempts
CREATE TABLE `extraction_attempts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `attemptId` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `documentId` int NOT NULL,
  `draftSessionId` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `generationId` int NOT NULL DEFAULT '1',
  `status` enum('pending','processing','completed','failed','canceled','superseded') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `translationId` int DEFAULT NULL,
  `createdBy` int NOT NULL,
  `startedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `completedAt` timestamp NULL DEFAULT NULL,
  `canceledAt` timestamp NULL DEFAULT NULL,
  `supersededBy` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `extraction_attempts_attemptId_unique` (`attemptId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1590001;

-- BASE TABLE: google_calendar_appointment_syncs
CREATE TABLE `google_calendar_appointment_syncs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `appointmentId` int NOT NULL,
  `provider` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'google',
  `googleCalendarId` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `googleEventId` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `operation` enum('upsert','delete') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'upsert',
  `syncStatus` enum('pending','synced','failed','deletion_pending','deleted') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payloadHash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastSyncedAt` timestamp NULL DEFAULT NULL,
  `lastSyncError` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `retryCount` int NOT NULL DEFAULT '0',
  `nextRetryAt` timestamp NULL DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `googleEventHtmlLink` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastVerifiedEventAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `google_calendar_appointment_syncs_appointmentId_unique` (`appointmentId`),
  KEY `google_calendar_appointment_syncs_retry_idx` (`syncStatus`,`nextRetryAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1320001;

-- BASE TABLE: google_calendar_connections
CREATE TABLE `google_calendar_connections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `provider` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connectedAccountEmail` varchar(320) COLLATE utf8mb4_unicode_ci NOT NULL,
  `encryptedRefreshToken` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `destinationCalendarId` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `destinationCalendarName` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `businessTimezone` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Europe/Istanbul',
  `status` enum('connected','needs_attention') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'connected',
  `connectedByUserId` int NOT NULL,
  `connectedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastValidatedAt` timestamp NULL DEFAULT NULL,
  `lastError` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `testEventId` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `testEventCalendarId` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `google_calendar_connections_provider_unique` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=60001;

-- BASE TABLE: google_calendar_oauth_states
CREATE TABLE `google_calendar_oauth_states` (
  `id` int NOT NULL AUTO_INCREMENT,
  `stateHash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` int NOT NULL,
  `expiresAt` timestamp NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `google_calendar_oauth_states_stateHash_unique` (`stateHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=120001;

-- BASE TABLE: intake_forms
CREATE TABLE `intake_forms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand` enum('fertiliv','safemedigo','dr-nilay-karaca') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fertiliv',
  `isDefault` tinyint(1) NOT NULL DEFAULT '0',
  `fields` json NOT NULL,
  `translations` json NOT NULL,
  `titleTranslations` json DEFAULT NULL,
  `subtitleTranslations` json DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `stepsMeta` json DEFAULT NULL COMMENT 'JSON array of step metadata including decision steps and per-step titles',
  `fieldConfig` json DEFAULT NULL COMMENT 'Per-field config overrides, e.g. {"f_art_history":{"enabledSubFields":["type","date"]}}',
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `intake_forms_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=750001;

-- BASE TABLE: invoice_items
CREATE TABLE `invoice_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoiceId` int NOT NULL,
  `serviceId` int DEFAULT NULL,
  `description` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL DEFAULT '1',
  `unitPrice` decimal(10,2) NOT NULL,
  `totalPrice` decimal(10,2) NOT NULL,
  `linePricingMethod` enum('none','discount_percent','final_line_total','agreed_unit_price') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `lineDiscountPercent` decimal(5,2) DEFAULT NULL,
  `taxRuleId` int DEFAULT NULL,
  `taxLabelSnapshot` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taxRateSnapshot` decimal(7,4) DEFAULT NULL,
  `taxIncludedMode` tinyint(1) DEFAULT NULL,
  `effectiveTaxableBase` decimal(10,2) DEFAULT NULL,
  `taxAmount` decimal(10,2) NOT NULL DEFAULT '0',
  `priceEntryCurrency` enum('USD','EUR','GBP','TRY','SAR','AED') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priceEntryAmount` decimal(18,2) DEFAULT NULL,
  `priceEntryKind` enum('unit_price','final_line_total','tax_included_final_line_total','agreed_unit_price','tax_included_agreed_unit_price') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priceFxRateToInvoice` decimal(20,12) DEFAULT NULL,
  `priceFxSourceToTryRate` decimal(20,12) DEFAULT NULL,
  `priceFxInvoiceToTryRate` decimal(20,12) DEFAULT NULL,
  `priceFxSource` enum('system','manual') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priceFxEffectiveAt` timestamp NULL DEFAULT NULL,
  `priceFxNote` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lineLabel` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1770001;

-- BASE TABLE: invoice_revisions
CREATE TABLE `invoice_revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `invoiceId` int NOT NULL,
  `revisionNumber` int NOT NULL,
  `status` enum('draft','published','discarded') COLLATE utf8mb4_unicode_ci NOT NULL,
  `parentPublishedRevisionId` int DEFAULT NULL,
  `snapshot` json NOT NULL,
  `changeSummary` json DEFAULT NULL,
  `previousTotals` json DEFAULT NULL,
  `publishedTotals` json DEFAULT NULL,
  `createdById` int DEFAULT NULL,
  `publishedById` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `publishedAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `invoice_revisions_invoice_revision_unique` (`invoiceId`,`revisionNumber`),
  KEY `invoice_revisions_invoice_status_idx` (`invoiceId`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=420001;

-- BASE TABLE: invoice_settlements
CREATE TABLE `invoice_settlements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patientId` int NOT NULL,
  `invoiceId` int NOT NULL,
  `financialScope` enum('production','test') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'production',
  `currency` enum('USD','EUR','GBP','TRY','SAR','AED','AUD') COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `sourceType` enum('payment','credit','fx_rounding_adjustment') COLLATE utf8mb4_unicode_ci NOT NULL,
  `paymentId` int DEFAULT NULL,
  `creditTransactionId` int DEFAULT NULL,
  `recordedById` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('active','voided') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `voidedAt` timestamp NULL DEFAULT NULL,
  `voidedById` int DEFAULT NULL,
  `voidReason` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sourceCreditCurrency` enum('USD','EUR','GBP','TRY','SAR','AED','AUD') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sourceCreditAmount` decimal(10,2) DEFAULT NULL,
  `creditConversionRateToInvoice` decimal(20,12) DEFAULT NULL,
  `creditFxEffectiveAt` timestamp NULL DEFAULT NULL,
  `creditFxSource` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fxRoundingReason` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fxRoundingSourceMinorUnit` decimal(10,2) DEFAULT NULL,
  `patientCreditApplicationId` int DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `idx_invoice_settlements_invoice` (`invoiceId`),
  KEY `idx_invoice_settlements_patient_scope_currency` (`patientId`,`financialScope`,`currency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1170001;

-- BASE TABLE: invoices
CREATE TABLE `invoices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patientId` int DEFAULT NULL,
  `invoiceNumber` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `issueDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dueDate` timestamp NULL DEFAULT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `discountAmount` decimal(10,2) DEFAULT '0',
  `taxAmount` decimal(10,2) DEFAULT '0',
  `totalAmount` decimal(10,2) NOT NULL,
  `paidAmount` decimal(10,2) DEFAULT '0',
  `status` enum('draft','issued','paid','partial','overdue','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `paymentMethod` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paymentDate` timestamp NULL DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdById` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `leadId` int DEFAULT NULL,
  `currency` enum('USD','EUR','GBP','TRY','SAR','AED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `discountPercent` decimal(5,2) DEFAULT '0',
  `externalReceiptKey` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exchangeRateSnapshot` decimal(14,6) DEFAULT NULL,
  `rateDirection` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT 'TRY_PER_UNIT',
  `snapshotSource` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `snapshotRateDate` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pricingMode` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'discount | agreed | discount_legacy',
  `finalAgreedAmount` decimal(10,2) DEFAULT NULL COMMENT 'V3: exact staff-entered final price (Mode B only)',
  `paymentAdjustmentRateSnapshot` decimal(5,2) DEFAULT NULL COMMENT 'V3: card_surcharge_pct at invoice creation time',
  `financialScope` enum('production','test') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'production',
  `taxModelVersion` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `settlementModelVersion` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currentRevisionNumber` int NOT NULL DEFAULT '1',
  `currentPublishedRevisionId` int DEFAULT NULL,
  `activeDraftRevisionId` int DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `invoices_invoiceNumber_unique` (`invoiceNumber`),
  KEY `idx_invoices_financialScope` (`financialScope`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1620001;

-- BASE TABLE: lab_dictionary
CREATE TABLE `lab_dictionary` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalName` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `displayName` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abbreviation` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resultType` enum('Quantitative','Qualitative','Molecular/PCR','Genetic','Microbiology Culture','Microscopy/Parasitology','Panel/Profile','Pathology/Biopsy','Semen Analysis','Semen DNA','Therapeutic Drug Monitoring','Descriptive/Report') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Quantitative',
  `category` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `specimen` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `commonUnits` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `suggestedModule` enum('general_lab','semen_analysis','semen_dna','genetic','radiology','pathology') COLLATE utf8mb4_unicode_ci DEFAULT 'general_lab',
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdById` int DEFAULT NULL,
  `updatedById` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `canonicalUnit` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alternativeUnits` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conversionFactors` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `analyteGroup` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `orderType` enum('Single Result Test','Timed Component','Protocol Name','Genetic / Molecular') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Single Result Test',
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=360001;

-- BASE TABLE: lab_dictionary_aliases
CREATE TABLE `lab_dictionary_aliases` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dictionaryId` int NOT NULL,
  `alias` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope` enum('global','patient') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `patientId` int DEFAULT NULL,
  `confirmedById` int DEFAULT NULL,
  `confirmedAt` timestamp NULL DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=840001;

-- BASE TABLE: lab_dictionary_changelog
CREATE TABLE `lab_dictionary_changelog` (
  `id` int NOT NULL AUTO_INCREMENT,
  `dictionaryId` int NOT NULL,
  `changeType` enum('created','updated','alias_added','alias_removed','approved_from_pending','bulk_enriched') COLLATE utf8mb4_unicode_ci NOT NULL,
  `fieldName` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oldValue` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `newValue` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aliasId` int DEFAULT NULL,
  `performedById` int DEFAULT NULL,
  `performedByName` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isUndone` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `idx_changelog_dictionaryId` (`dictionaryId`),
  KEY `idx_changelog_createdAt` (`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=420001;

-- BASE TABLE: lab_orders
CREATE TABLE `lab_orders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patientId` int NOT NULL,
  `doctorId` int DEFAULT NULL,
  `appointmentId` int DEFAULT NULL,
  `serviceId` int DEFAULT NULL,
  `orderNumber` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `testName` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` enum('lab','radiology','pathology','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'lab',
  `status` enum('ordered','sample_collected','processing','completed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ordered',
  `priority` enum('routine','urgent','stat') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'routine',
  `orderedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `collectedDate` timestamp NULL DEFAULT NULL,
  `resultDate` timestamp NULL DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `partnerClinicId` int DEFAULT NULL,
  `location` enum('in-clinic','partner-clinic','patient-country') COLLATE utf8mb4_unicode_ci DEFAULT 'in-clinic',
  `invoiceId` int DEFAULT NULL,
  `invoiceStatus` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `lab_orders_orderNumber_unique` (`orderNumber`),
  UNIQUE KEY `idx_lab_orders_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=30001;

-- BASE TABLE: lab_results
CREATE TABLE `lab_results` (
  `id` int NOT NULL AUTO_INCREMENT,
  `labOrderId` int NOT NULL,
  `patientId` int NOT NULL,
  `parameter` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `unit` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referenceRange` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flag` enum('normal','low','high','critical') COLLATE utf8mb4_unicode_ci DEFAULT 'normal',
  `interpretation` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reportUrl` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enteredById` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `resultFileKey` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `resultFileUrl` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `translationFileKey` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `translationFileUrl` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isVisibleToPatient` tinyint(1) NOT NULL DEFAULT '0',
  `sampleCollectedAt` timestamp NULL DEFAULT NULL,
  `reportedAt` timestamp NULL DEFAULT NULL,
  `refRangeFrom` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `refRangeTo` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unitConversionFormula` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `flagManualOverride` tinyint(1) DEFAULT '0',
  `clinicalInterpretation` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=30001;

-- BASE TABLE: lead_communications
CREATE TABLE `lead_communications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `leadId` int NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdBy` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `noteCreatedAt` timestamp NULL DEFAULT NULL,
  `updatedAt` timestamp NULL DEFAULT NULL,
  `updatedBy` int DEFAULT NULL,
  `deletedAt` timestamp NULL DEFAULT NULL,
  `deletedBy` int DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1530001;

-- BASE TABLE: lead_documents
CREATE TABLE `lead_documents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `leadId` int DEFAULT NULL,
  `fileKey` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileUrl` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileName` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mimeType` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploadedBy` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `patientId` int DEFAULT NULL,
  `tag` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `intakeSection` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docPassword` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ownerType` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ownerId` int DEFAULT NULL,
  `lifecycleStatus` enum('active','historical','direct-upload','deletion-pending','pending-draft') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sourceIntakeId` int DEFAULT NULL,
  `archivedAt` timestamp NULL DEFAULT NULL,
  `archiveReason` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `storageDeletePending` tinyint(1) NOT NULL DEFAULT '0',
  `draftSessionId` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `draftLastActivityAt` timestamp NULL DEFAULT NULL,
  `pendingExpiresAt` timestamp NULL DEFAULT NULL,
  `pendingCreatedBy` int DEFAULT NULL,
  `pendingSection` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pendingEntryKey` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `promotedAt` timestamp NULL DEFAULT NULL,
  `storageDeleteAttempts` int NOT NULL DEFAULT '0',
  `lastStorageDeleteAttemptAt` timestamp NULL DEFAULT NULL,
  `lastStorageDeleteError` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cleanupAlertedAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2790001;

-- BASE TABLE: leads
CREATE TABLE `leads` (
  `id` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `middleName` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastName` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dateOfBirth` date DEFAULT NULL,
  `email` varchar(320) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secondaryPhone` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secondaryEmail` varchar(320) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nationality` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `patientType` enum('local','international','not-specified') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preferredLanguages` json DEFAULT NULL,
  `preferredContactMethods` json DEFAULT NULL,
  `preferredLanguage_old` enum('en','ar','tr','fr','es','ru','it','other') COLLATE utf8mb4_unicode_ci DEFAULT 'en',
  `preferredContactMethod_old` enum('whatsapp','email','phone','telegram') COLLATE utf8mb4_unicode_ci DEFAULT 'whatsapp',
  `interestedProcedureId` int DEFAULT NULL,
  `ivfExperience` enum('never-tried','tried-unsuccessful','tried-again','tried-multiple') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fertilityDiagnosis` json DEFAULT NULL,
  `leadSource` enum('paid','employee-referral','external-referral','website','maps','partner','public-relations','instagram','tiktok','doctor-referral','youtube','facebook','awatef-guide','salim-guide','organic') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `socialLeadId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaignName` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand` enum('fertiliv','safemedigo','dr-nilay-karaca') COLLATE utf8mb4_unicode_ci DEFAULT 'fertiliv',
  `budgetRange` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `decisionTimeline` enum('immediately','1-2-weeks','1-month','2-months','3-months','1-3-months','6-months','exploring') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `travelReadiness` enum('ready','considering','prefers-home','local-patient') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `leadStatus` enum('intake','attempted-to-contact','contacted-awaiting-info','medical-reports-received','doctor-feedback-shared','follow-up-negotiation','ready-to-travel','converted','cold','lost','not-qualified','junk') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'intake',
  `rating` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assignedStaffId` int DEFAULT NULL,
  `lastContactDate` timestamp NULL DEFAULT NULL,
  `nextFollowUpDate` timestamp NULL DEFAULT NULL,
  `tags` json DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accommodationHotel` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accommodationLocation` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transportationAirportPickup` tinyint(1) DEFAULT NULL,
  `transportationLocalTransfer` tinyint(1) DEFAULT NULL,
  `convertedPatientId` int DEFAULT NULL,
  `createdBy` int DEFAULT NULL,
  `modifiedBy` int DEFAULT NULL,
  `modifiedAt` timestamp NULL DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `caseSummary` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salesNote` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `partnerId` int DEFAULT NULL,
  `gender` enum('male','female','other') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mainMedicalInterest` json DEFAULT NULL,
  `callbackRequestedAt` timestamp NULL DEFAULT NULL,
  `callbackPreferredDate` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `callbackPreferredTime` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `callbackMethod` enum('whatsapp','phone','video_call','email') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `intakeToken` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `leadOrigin` enum('staff-created','self-submitted') COLLATE utf8mb4_unicode_ci DEFAULT 'staff-created',
  `mergedIntoLeadId` int DEFAULT NULL,
  `mergedAt` timestamp NULL DEFAULT NULL,
  `primaryLanguage` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assignedDoctorId` int DEFAULT NULL,
  `maleFertilityDiagnosis` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tcKimlikNo` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passportNumber` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emailVerified` tinyint(1) NOT NULL DEFAULT '0',
  `formSessionToken` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otpCode` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otpExpiresAt` timestamp NULL DEFAULT NULL,
  `caseSummaryTranslations` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salesNoteTranslations` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `interestLevel` enum('cold','warm','hot') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contactRole` enum('female-patient','male-patient','husband-for-couple','wife-for-couple','family-member','agent','unknown') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serviceFor` enum('female-only','male-only','couple') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profileCompleteness` int DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `idx_leads_code` (`code`),
  UNIQUE KEY `leads_convertedPatientId_unique` (`convertedPatientId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=5490001;

-- BASE TABLE: medical_intake
CREATE TABLE `medical_intake` (
  `id` int NOT NULL AUTO_INCREMENT,
  `leadId` int DEFAULT NULL,
  `marriageDate` timestamp NULL DEFAULT NULL,
  `currentMedications` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additionalNotes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expectedVisitDate` timestamp NULL DEFAULT NULL,
  `hasCivilMarriageCertificate` tinyint(1) DEFAULT '0',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `patientId` int DEFAULT NULL,
  `infertilityType` enum('primary','secondary') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `infertilityDuration` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referralSource` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profession` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isFirstMarriage` tinyint(1) DEFAULT NULL,
  `partnerIsFirstMarriage` tinyint(1) DEFAULT NULL,
  `heightCm` decimal(5,1) DEFAULT NULL,
  `weightKg` decimal(5,1) DEFAULT NULL,
  `bmi` decimal(4,1) DEFAULT NULL,
  `bmiManual` tinyint(1) NOT NULL DEFAULT '0',
  `waistCm` decimal(5,1) DEFAULT NULL,
  `hipCm` decimal(5,1) DEFAULT NULL,
  `gravida` int NOT NULL DEFAULT '0',
  `para` int NOT NULL DEFAULT '0',
  `abortus` int NOT NULL DEFAULT '0',
  `livingChildren` int NOT NULL DEFAULT '0',
  `childrenFromPreviousMarriage` int NOT NULL DEFAULT '0',
  `lastMenstrualPeriod` timestamp NULL DEFAULT NULL,
  `cycleRegularity` enum('regular','irregular','absent') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cycleLengthDays` int DEFAULT NULL,
  `menstrualFlowDays` int DEFAULT NULL,
  `dysmenorrhea` tinyint(1) NOT NULL DEFAULT '0',
  `miscarriageHistory` json DEFAULT NULL,
  `artHistory` json DEFAULT NULL,
  `surgicalHistory` json DEFAULT NULL,
  `previousTests` json DEFAULT NULL,
  `previousProcedures` json DEFAULT NULL,
  `systemicDiseases` json DEFAULT NULL,
  `smoking` enum('never','former','current') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smokingPacksPerDay` decimal(3,1) DEFAULT NULL,
  `alcohol` enum('never','occasional','regular') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allergies` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hirsutism` tinyint(1) NOT NULL DEFAULT '0',
  `consanguinity` tinyint(1) NOT NULL DEFAULT '0',
  `hereditaryDiseases` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `familyBreastCancer` tinyint(1) NOT NULL DEFAULT '0',
  `familyEarlyMenopause` tinyint(1) NOT NULL DEFAULT '0',
  `familyInfertility` tinyint(1) NOT NULL DEFAULT '0',
  `maleIntake` json DEFAULT NULL,
  `patientQuestions` json DEFAULT NULL,
  `doctorAnswers` json DEFAULT NULL,
  `radiologyStudies` json DEFAULT NULL,
  `maleRadiologyStudies` json DEFAULT NULL,
  `generalAttachmentsFemale` json DEFAULT NULL,
  `generalAttachmentsMale` json DEFAULT NULL,
  `contraceptiveHistory` json DEFAULT NULL COMMENT 'Array of {method: string, duration: string, stoppedDate: string, notes: string}',
  `hasRadiologyStudies` tinyint(1) DEFAULT '0',
  `hasMaleRadiologyStudies` tinyint(1) DEFAULT '0',
  `marriageCertFileKey` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marriageCertFileUrl` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marriageCertFileName` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marriageCertDocId` int DEFAULT NULL,
  `marriageCertFilePassword` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marriageCertStatus` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT 'not_specified',
  `personGender` enum('female','male') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `maleIntakeMigrated` tinyint(1) NOT NULL DEFAULT '0',
  `maleIntakeMigratedAt` timestamp NULL DEFAULT NULL,
  `maleIntakeMigratedBy` int DEFAULT NULL,
  `intakeMode` enum('legacy','female','male','general') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `femaleGeneticTests` json DEFAULT NULL COMMENT 'Female genetic tests: [{test, date, result, notes, fileKey, fileUrl, fileName, filePassword, docId}]',
  `hasPreviousTests` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `medical_intake_leadId_unique` (`leadId`),
  UNIQUE KEY `medical_intake_patientId_unique` (`patientId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=6060001;

-- BASE TABLE: medical_notes
CREATE TABLE `medical_notes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patientId` int NOT NULL,
  `doctorId` int DEFAULT NULL,
  `authorId` int NOT NULL,
  `noteType` enum('consultation','follow_up','procedure','lab_review','general') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'consultation',
  `chiefComplaint` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `historyOfPresentIllness` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `physicalExamination` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assessment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plan` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diagnosis` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `medications` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rawTranscript` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aiSummary` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isAiGenerated` tinyint(1) DEFAULT '0',
  `visitDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `enteredById` int DEFAULT NULL,
  `additionalNotes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancellation_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancellation_reason` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancellation_requested_by` int DEFAULT NULL,
  `cancellation_requested_at` bigint DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=720001;

-- BASE TABLE: medication_adherence_log
CREATE TABLE `medication_adherence_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cycleId` int NOT NULL,
  `medicationId` int NOT NULL,
  `patientId` int NOT NULL,
  `scheduledDate` timestamp NOT NULL,
  `confirmedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `confirmedByPatient` tinyint(1) NOT NULL DEFAULT '1',
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=60001;

-- BASE TABLE: messages
CREATE TABLE `messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fromUserId` int NOT NULL,
  `toUserId` int NOT NULL,
  `subject` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `isRead` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- BASE TABLE: migration_conflict_log
CREATE TABLE `migration_conflict_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `conflictType` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sourceRecordType` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sourceRecordId` int DEFAULT NULL,
  `targetRecordType` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `targetRecordId` int DEFAULT NULL,
  `fieldName` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sourceValue` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `targetValue` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `suggestedAction` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','ready_for_admin_review','resolved','dismissed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `flaggedBy` int DEFAULT NULL,
  `flaggedAt` timestamp NULL DEFAULT NULL,
  `resolvedBy` int DEFAULT NULL,
  `resolvedAt` timestamp NULL DEFAULT NULL,
  `resolutionDecision` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `adminNotes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- BASE TABLE: monitoring_consents
CREATE TABLE `monitoring_consents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `consentedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ipAddress` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `userAgent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=60001;

-- BASE TABLE: monitoring_sessions
CREATE TABLE `monitoring_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `adminId` int NOT NULL,
  `employeeId` int NOT NULL,
  `monitoringType` enum('screen','screenshot','camera','microphone') COLLATE utf8mb4_unicode_ci NOT NULL,
  `startTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `endTime` timestamp NULL DEFAULT NULL,
  `durationSeconds` int DEFAULT NULL,
  `screenshotUrls` json DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=120001;

-- BASE TABLE: monitoring_settings
CREATE TABLE `monitoring_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `screenEnabled` tinyint(1) NOT NULL DEFAULT '0',
  `screenshotEnabled` tinyint(1) NOT NULL DEFAULT '0',
  `screenshotIntervalSeconds` int NOT NULL DEFAULT '60',
  `cameraEnabled` tinyint(1) NOT NULL DEFAULT '0',
  `microphoneEnabled` tinyint(1) NOT NULL DEFAULT '0',
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedById` int DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=30002;

-- BASE TABLE: monitoring_signals
CREATE TABLE `monitoring_signals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `session_id` varchar(64) NOT NULL,
  `from_user_id` int NOT NULL,
  `to_user_id` int NOT NULL,
  `type` enum('offer','answer','ice-candidate','request','reject','end') NOT NULL,
  `payload` text NOT NULL,
  `consumed` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` bigint NOT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `idx_signals_to_user` (`to_user_id`,`consumed`),
  KEY `idx_signals_session` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin AUTO_INCREMENT=30001;

-- BASE TABLE: mrn_counter
CREATE TABLE `mrn_counter` (
  `id` int NOT NULL DEFAULT '1',
  `next_value` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- BASE TABLE: notifications
CREATE TABLE `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` enum('appointment_reminder','appointment_cancellation','invoice_issued','payment_confirmed','lab_result_ready','inbox_new_conversation','inbox_new_message','inbox_assignment','inbox_reassignment','inbox_crm_review','whatsapp_line_health','general') COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `isRead` tinyint(1) NOT NULL DEFAULT '0',
  `relatedId` int DEFAULT NULL,
  `relatedType` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dedupeKey` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `notifications_user_dedupe_uq` (`userId`,`dedupeKey`),
  KEY `notifications_user_created_ix` (`userId`,`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=4020001;

-- BASE TABLE: offers
CREATE TABLE `offers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patientId` int DEFAULT NULL,
  `title` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discountType` enum('percentage','fixed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'percentage',
  `discountValue` decimal(10,2) NOT NULL,
  `validFrom` timestamp NULL DEFAULT NULL,
  `validUntil` timestamp NULL DEFAULT NULL,
  `status` enum('active','expired','used') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `code` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=30001;

-- BASE TABLE: partner_clinics
CREATE TABLE `partner_clinics` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `specialty` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `googleMapsUrl` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `idx_partner_clinics_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=90001;

-- BASE TABLE: password_reset_tokens
CREATE TABLE `password_reset_tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiresAt` timestamp NOT NULL,
  `usedAt` timestamp NULL DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `password_reset_tokens_token_unique` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=30001;

-- BASE TABLE: patient_communications
CREATE TABLE `patient_communications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patientId` int NOT NULL,
  `note` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdBy` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NULL DEFAULT NULL,
  `updatedBy` int DEFAULT NULL,
  `deletedAt` timestamp NULL DEFAULT NULL,
  `deletedBy` int DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=390001;

-- BASE TABLE: patient_credit_application_allocations
CREATE TABLE `patient_credit_application_allocations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `applicationId` int NOT NULL,
  `sourceCreditTransactionId` int NOT NULL,
  `creditDebitTransactionId` int NOT NULL,
  `creditSettlementId` int NOT NULL,
  `nativeSourceAmount` decimal(10,2) NOT NULL,
  `targetSettlementAmount` decimal(10,2) NOT NULL,
  `reversalCreditTransactionId` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `patient_credit_application_allocations_application_idx` (`applicationId`),
  KEY `patient_credit_application_allocations_source_idx` (`sourceCreditTransactionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=90001;

-- BASE TABLE: patient_credit_application_reversals
CREATE TABLE `patient_credit_application_reversals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `applicationId` int NOT NULL,
  `patientId` int NOT NULL,
  `invoiceId` int NOT NULL,
  `financialScope` enum('production','test') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'production',
  `restoredSourceAmount` decimal(10,2) NOT NULL,
  `reversedCreditSettlementAmount` decimal(10,2) NOT NULL,
  `reversedFxRoundingAdjustmentAmount` decimal(10,2) NOT NULL DEFAULT '0',
  `reason` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recordedById` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `idempotencyKey` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `patient_credit_application_reversals_application_uq` (`applicationId`),
  KEY `patient_credit_application_reversals_invoice_idx` (`invoiceId`),
  UNIQUE KEY `patient_credit_application_reversals_idempotency_uq` (`idempotencyKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=90001;

-- BASE TABLE: patient_credit_applications
CREATE TABLE `patient_credit_applications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patientId` int NOT NULL,
  `invoiceId` int NOT NULL,
  `financialScope` enum('production','test') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'production',
  `sourceCurrency` enum('USD','EUR','GBP','TRY','SAR','AED','AUD') COLLATE utf8mb4_unicode_ci NOT NULL,
  `targetInvoiceCurrency` enum('USD','EUR','GBP','TRY','SAR','AED','AUD') COLLATE utf8mb4_unicode_ci NOT NULL,
  `sourceCreditAmount` decimal(10,2) NOT NULL,
  `creditSettlementAmount` decimal(10,2) NOT NULL,
  `fxRoundingAdjustmentAmount` decimal(10,2) NOT NULL DEFAULT '0',
  `finalSettlementAmount` decimal(10,2) NOT NULL,
  `conversionRateToInvoice` decimal(20,12) DEFAULT NULL,
  `fxEffectiveAt` timestamp NULL DEFAULT NULL,
  `fxSource` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','reversed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `reversalReason` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reversedAt` timestamp NULL DEFAULT NULL,
  `reversedById` int DEFAULT NULL,
  `createdById` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `patient_credit_applications_invoice_status_idx` (`invoiceId`,`status`),
  KEY `patient_credit_applications_patient_scope_idx` (`patientId`,`financialScope`,`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=90001;

-- BASE TABLE: patient_credit_payout_allocations
CREATE TABLE `patient_credit_payout_allocations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `payoutId` int NOT NULL,
  `sourceCreditTransactionId` int NOT NULL,
  `creditDebitTransactionId` int NOT NULL,
  `nativeSourceAmount` decimal(10,2) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `patient_credit_payout_allocations_payout_idx` (`payoutId`),
  KEY `patient_credit_payout_allocations_source_idx` (`sourceCreditTransactionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=180001;

-- BASE TABLE: patient_credit_payouts
CREATE TABLE `patient_credit_payouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patientId` int NOT NULL,
  `financialScope` enum('production','test') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'production',
  `sourceCurrency` enum('USD','EUR','GBP','TRY','SAR','AED','AUD') COLLATE utf8mb4_unicode_ci NOT NULL,
  `sourceCreditAmount` decimal(10,2) NOT NULL,
  `payoutCurrency` enum('USD','EUR','GBP','TRY','SAR','AED','AUD') COLLATE utf8mb4_unicode_ci NOT NULL,
  `payoutAmount` decimal(10,2) NOT NULL,
  `conversionRateToPayout` decimal(20,12) DEFAULT NULL,
  `fxEffectiveAt` timestamp NULL DEFAULT NULL,
  `fxSource` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `method` enum('cash','bank_transfer') COLLATE utf8mb4_unicode_ci NOT NULL,
  `payoutDate` timestamp NOT NULL,
  `reference` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recordedById` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `idempotencyKey` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `patient_credit_payouts_patient_scope_idx` (`patientId`,`financialScope`,`createdAt`),
  UNIQUE KEY `patient_credit_payouts_idempotency_uq` (`idempotencyKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=180001;

-- BASE TABLE: patient_doctors
CREATE TABLE `patient_doctors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patientId` int NOT NULL,
  `doctorId` int NOT NULL,
  `isPrimary` tinyint(1) NOT NULL DEFAULT '0',
  `assignedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `assignedBy` int DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=3090001;

-- BASE TABLE: patients
CREATE TABLE `patients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int DEFAULT NULL,
  `mrn` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstName` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `middleName` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastName` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dateOfBirth` date DEFAULT NULL,
  `gender` enum('male','female','other') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secondaryPhone` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(320) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bloodType` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allergies` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyContactName` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergencyContactPhone` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `insuranceProvider` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `insuranceNumber` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assignedDoctorId` int DEFAULT NULL,
  `interestLevel` enum('cold','warm','hot') COLLATE utf8mb4_unicode_ci DEFAULT 'warm',
  `leadSource` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('inquiry','lead','qualified','proposal_sent','active_patient','inactive','archived') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active_patient',
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nationality` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isLocalPatient` tinyint(1) DEFAULT '0',
  `brand` enum('fertiliv','safemedigo','dr-nilay-karaca') COLLATE utf8mb4_unicode_ci DEFAULT 'fertiliv',
  `createdBy` int DEFAULT NULL,
  `modifiedBy` int DEFAULT NULL,
  `modifiedAt` timestamp NULL DEFAULT NULL,
  `partnerId` int DEFAULT NULL,
  `preferredLanguage_old` enum('en','ar','tr','fr','es','ru','it','other') COLLATE utf8mb4_unicode_ci DEFAULT 'en',
  `preferredLanguages` json DEFAULT NULL,
  `source` enum('paid','employee-referral','external-referral','website','maps','partner','public-relations','instagram','tiktok','doctor-referral','youtube','facebook','awatef-guide','salim-guide','organic') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `socialLeadId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaignName` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `budgetRange` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rating` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `travelReadiness` enum('ready','considering','prefers-home','local-patient') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fertilityDiagnosis` json DEFAULT NULL,
  `ivfExperience` enum('never-tried','tried-unsuccessful','tried-again','tried-multiple') COLLATE utf8mb4_unicode_ci DEFAULT 'never-tried',
  `decisionTimeline` enum('immediately','1-2-weeks','1-month','2-months','3-months','1-3-months','6-months','exploring') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preferredContactMethod_old` enum('whatsapp','email','phone','telegram') COLLATE utf8mb4_unicode_ci DEFAULT 'whatsapp',
  `preferredContactMethods` json DEFAULT NULL,
  `assignedStaffId` int DEFAULT NULL,
  `lastContactDate` timestamp NULL DEFAULT NULL,
  `nextFollowUpDate` timestamp NULL DEFAULT NULL,
  `city` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accommodationHotel` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accommodationLocation` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transportationAirportPickup` tinyint(1) DEFAULT '0',
  `transportationLocalTransfer` tinyint(1) DEFAULT '0',
  `caseSummary` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salesNote` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `patientType` enum('local','international') COLLATE utf8mb4_unicode_ci DEFAULT 'international',
  `creditBalance` decimal(10,2) DEFAULT '0',
  `mainMedicalInterest` json DEFAULT NULL,
  `countryOfResidency` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secondaryEmail` varchar(320) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primaryLanguage` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interestedProcedureId` int DEFAULT NULL,
  `maleFertilityDiagnosis` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caseSummaryTranslations` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salesNoteTranslations` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `defaultFinancialScope` enum('production','test') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'production',
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `patients_mrn_unique` (`mrn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=4020001;

-- BASE TABLE: payments
CREATE TABLE `payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patientId` int DEFAULT NULL,
  `invoiceId` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` enum('USD','EUR','GBP','TRY','SAR','AED','AUD') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'TRY',
  `method` enum('cash','credit_card','bank_transfer','insurance','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cash',
  `recordedById` int NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `exchangeRateAtPayment` decimal(12,4) NOT NULL DEFAULT '1.0000' COMMENT '1 FOREIGN = X TRY at time of payment. Always 1 for TRY payments.',
  `conversionRateToInvoice` decimal(20,12) NOT NULL,
  `amountInInvoiceCurrency` decimal(18,2) NOT NULL,
  `settledAmount` decimal(10,2) NOT NULL COMMENT 'Amount of invoice obligation settled by this payment (in invoice currency). For cash and Mode B: equals amountInInvoiceCurrency. For Mode A non-cash (credit_card/bank_transfer): amountInInvoiceCurrency / (1 + adjustmentRate/100).',
  `status` enum('active','voided') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `voidedAt` timestamp NULL DEFAULT NULL,
  `voidedById` int DEFAULT NULL,
  `voidReason` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receivedAt` timestamp NULL DEFAULT NULL COMMENT 'Actual date/time money was received; required for new payment creation, NULL for historical rows with unknown actual transaction time',
  `fxEffectiveAt` timestamp NULL DEFAULT NULL COMMENT 'Effective date/time of the approved FX observation used for this payment; NULL for historical rows where it was not retained',
  `financialScope` enum('production','test') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'production',
  `fxRateSource` enum('system','manual') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fxRateNote` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bankGrossAmountSent` decimal(10,2) DEFAULT NULL,
  `bankDeductionAmount` decimal(10,2) DEFAULT NULL,
  `bankDeductionPercent` decimal(9,4) DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `idx_payments_invoiceId` (`invoiceId`),
  KEY `idx_payments_patientId` (`patientId`),
  KEY `idx_payments_financialScope` (`financialScope`),
  CONSTRAINT `fk_payments_invoiceId` FOREIGN KEY (`invoiceId`) REFERENCES `invoices` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_payments_patientId` FOREIGN KEY (`patientId`) REFERENCES `patients` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1680001;

-- BASE TABLE: pending_lab_tests
CREATE TABLE `pending_lab_tests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rawName` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source` enum('patient_entry','pdf_import') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'patient_entry',
  `patientId` int DEFAULT NULL,
  `suggestedCanonicalName` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `suggestedDisplayName` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `suggestedAbbreviation` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `suggestedResultType` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `suggestedCategory` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `suggestedSpecimen` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `suggestedUnits` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aiConfidence` enum('high','medium','low') COLLATE utf8mb4_unicode_ci DEFAULT 'medium',
  `possibleMatchId` int DEFAULT NULL,
  `possibleMatchName` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `possibleMatchScore` int DEFAULT NULL,
  `status` enum('pending','approved','rejected','merged') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `mergedIntoDictionaryId` int DEFAULT NULL,
  `rejectionReason` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submittedById` int NOT NULL,
  `reviewedById` int DEFAULT NULL,
  `reviewedAt` timestamp NULL DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `medicalVerdict` enum('same','different','related_separate','unclear') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confidenceScore` int DEFAULT NULL,
  `medicalReason` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `suggestedAction` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=480001;

-- BASE TABLE: proposal_items
CREATE TABLE `proposal_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `proposalId` int NOT NULL,
  `serviceId` int DEFAULT NULL,
  `description` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL DEFAULT '1',
  `unitPrice` decimal(10,2) NOT NULL,
  `discount` decimal(10,2) DEFAULT '0',
  `totalPrice` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=60001;

-- BASE TABLE: reference_data
CREATE TABLE `reference_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` enum('language','country','city','nationality') COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `labelAr` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `labelTr` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sortOrder` int DEFAULT '0',
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=30001;

-- BASE TABLE: refunds
CREATE TABLE `refunds` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patientId` int NOT NULL,
  `invoiceId` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` enum('USD','EUR','GBP','TRY','SAR','AED') COLLATE utf8mb4_unicode_ci NOT NULL,
  `amountInInvoiceCurrency` decimal(10,2) DEFAULT NULL,
  `conversionRateToInvoice` decimal(20,12) DEFAULT NULL,
  `fxEffectiveAt` timestamp NULL DEFAULT NULL,
  `method` enum('cash','bank_transfer','card_reversal','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cash',
  `refundDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recordedById` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `financialScope` enum('production','test') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'production',
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `idx_refunds_invoiceId` (`invoiceId`),
  KEY `idx_refunds_patientId` (`patientId`),
  KEY `idx_refunds_financialScope` (`financialScope`),
  CONSTRAINT `fk_refunds_invoiceId` FOREIGN KEY (`invoiceId`) REFERENCES `invoices` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_refunds_patientId` FOREIGN KEY (`patientId`) REFERENCES `patients` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=330001;

-- BASE TABLE: sales_notes
CREATE TABLE `sales_notes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patientId` int DEFAULT NULL,
  `authorId` int NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `leadId` int DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=30001;

-- BASE TABLE: sales_tasks
CREATE TABLE `sales_tasks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patientId` int DEFAULT NULL,
  `assignedToId` int DEFAULT NULL,
  `title` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dueDate` timestamp NULL DEFAULT NULL,
  `priority` enum('low','medium','high') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'medium',
  `status` enum('pending','in_progress','completed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `leadId` int DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=30001;

-- BASE TABLE: save_idempotency
CREATE TABLE `save_idempotency` (
  `id` int NOT NULL AUTO_INCREMENT,
  `requestId` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `draftSessionId` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `leadId` int DEFAULT NULL,
  `patientId` int DEFAULT NULL,
  `payloadHash` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('processing','completed','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'processing',
  `resultIntakeId` int DEFAULT NULL,
  `resultPromotedDocIds` json DEFAULT NULL,
  `resultArchivedDocIds` json DEFAULT NULL,
  `errorMessage` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `save_idempotency_requestId_unique` (`requestId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1590001;

-- BASE TABLE: service_category_tax_defaults
CREATE TABLE `service_category_tax_defaults` (
  `category` enum('lab_test','radiology_test','pathology_test','other_test','procedure','consultation','medicine') COLLATE utf8mb4_unicode_ci NOT NULL,
  `taxRuleId` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`category`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- BASE TABLE: service_tax_rules
CREATE TABLE `service_tax_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `label` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ratePercent` decimal(7,4) NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `sortOrder` int NOT NULL DEFAULT '0',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=30001;

-- BASE TABLE: services
CREATE TABLE `services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` enum('lab_test','radiology_test','pathology_test','other_test','procedure','consultation','medicine') COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `duration` int DEFAULT NULL,
  `preparationInstructions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `code` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `localPriceUSD` decimal(10,2) DEFAULT NULL,
  `localPriceEUR` decimal(10,2) DEFAULT NULL,
  `localPriceGBP` decimal(10,2) DEFAULT NULL,
  `localPriceTRY` decimal(10,2) DEFAULT NULL,
  `intlPriceUSD` decimal(10,2) DEFAULT NULL,
  `intlPriceEUR` decimal(10,2) DEFAULT NULL,
  `intlPriceGBP` decimal(10,2) DEFAULT NULL,
  `intlPriceTRY` decimal(10,2) DEFAULT NULL,
  `taxOverrideMode` enum('inherit','rule','no_tax') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'inherit',
  `taxOverrideRuleId` int DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=420001;

-- BASE TABLE: specializations
CREATE TABLE `specializations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=150001;

-- BASE TABLE: staff_availability
CREATE TABLE `staff_availability` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `title` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `startDate` timestamp NOT NULL,
  `endDate` timestamp NOT NULL,
  `reason` enum('vacation','sick_leave','training','personal','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'other',
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdBy` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=750001;

-- BASE TABLE: staff_permissions
CREATE TABLE `staff_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `module` enum('leads','patients','calendar','finance','lab','settings','analytics') COLLATE utf8mb4_unicode_ci NOT NULL,
  `canView` tinyint(1) NOT NULL DEFAULT '1',
  `canCreate` tinyint(1) NOT NULL DEFAULT '0',
  `canEdit` tinyint(1) NOT NULL DEFAULT '0',
  `canDelete` tinyint(1) NOT NULL DEFAULT '0',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=30001;

-- BASE TABLE: sub_specializations
CREATE TABLE `sub_specializations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `specializationId` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=90001;

-- BASE TABLE: system_settings
CREATE TABLE `system_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedBy` int DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `system_settings_key_unique` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=180001;

-- BASE TABLE: task_tags
CREATE TABLE `task_tags` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT '#6366f1',
  `createdByUserId` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=60001;

-- BASE TABLE: tasks
CREATE TABLE `tasks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('callback_request','follow_up','send_info','consultation_request','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'follow_up',
  `status` enum('open','in_progress','done','deferred') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `priority` enum('low','medium','high') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'medium',
  `dueDate` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dueTime` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `communicationMethod` enum('whatsapp','phone_call','video_call','email','in_person') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `leadId` int DEFAULT NULL,
  `patientId` int DEFAULT NULL,
  `assignedToId` int DEFAULT NULL,
  `createdById` int DEFAULT NULL,
  `tags` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `closedAt` timestamp NULL DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1200001;

-- BASE TABLE: treatment_cases
CREATE TABLE `treatment_cases` (
  `id` int NOT NULL AUTO_INCREMENT,
  `caseType` enum('ivf','icsi','iui','egg_freezing','sperm_freezing','micro_tese','other') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primaryLeadId` int DEFAULT NULL,
  `primaryPatientId` int DEFAULT NULL,
  `partnerLeadId` int DEFAULT NULL,
  `partnerPatientId` int DEFAULT NULL,
  `status` enum('active','completed','cancelled','on_hold') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdBy` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- BASE TABLE: treatment_cycles
CREATE TABLE `treatment_cycles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `patientId` int NOT NULL,
  `ivfNo` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cycleType` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `protocol` enum('antagonist','long','oks_long','patch_ant','mikrodoz','other') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('planned','stimulation','retrieval','transfer','completed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'planned',
  `doctorId` int DEFAULT NULL,
  `startDate` timestamp NULL DEFAULT NULL,
  `endDate` timestamp NULL DEFAULT NULL,
  `d3Tsh` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `d3Fsh` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `d3Lh` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `d3E2` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `d3Amh` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `d3Prl` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `d3Bmi` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `infertilityDuration` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `infertilityReasonFemale` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `infertilityReasonMale` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `frozenTissue` tinyint(1) DEFAULT '0',
  `spermCount` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `spermMotility` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `spermMorphology` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `spermTmss` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `karyotype` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serology` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previousTreatment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `surgery` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `adjuvantMedications` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdBy` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `idx_treatment_cycles_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=150001;

-- BASE TABLE: treatment_packages
CREATE TABLE `treatment_packages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `services` json DEFAULT NULL,
  `localPriceUSD` decimal(10,2) DEFAULT NULL,
  `localPriceEUR` decimal(10,2) DEFAULT NULL,
  `localPriceGBP` decimal(10,2) DEFAULT NULL,
  `localPriceTRY` decimal(10,2) DEFAULT NULL,
  `intlPriceUSD` decimal(10,2) DEFAULT NULL,
  `intlPriceEUR` decimal(10,2) DEFAULT NULL,
  `intlPriceGBP` decimal(10,2) DEFAULT NULL,
  `intlPriceTRY` decimal(10,2) DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `idx_treatment_packages_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=30001;

-- BASE TABLE: treatment_plan_scenarios
CREATE TABLE `treatment_plan_scenarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `treatmentPlanId` int NOT NULL,
  `title` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `summary` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `services` json DEFAULT NULL,
  `sortOrder` int NOT NULL DEFAULT '0',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=90001;

-- BASE TABLE: treatment_plans
CREATE TABLE `treatment_plans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `leadId` int DEFAULT NULL,
  `patientId` int DEFAULT NULL,
  `doctorId` int DEFAULT NULL,
  `status` enum('draft','confirmed','sent') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `clinicalSummary` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qaAnswers` json DEFAULT NULL,
  `confirmedAt` timestamp NULL DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `title` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `requestNotes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `requestedById` int DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=240001;

-- BASE TABLE: treatment_proposals
CREATE TABLE `treatment_proposals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `leadId` int DEFAULT NULL,
  `patientId` int DEFAULT NULL,
  `packageId` int DEFAULT NULL,
  `currency` enum('USD','EUR','GBP','TRY') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `appliedPriceType` enum('local','international') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'international',
  `totalAmount` decimal(10,2) DEFAULT NULL,
  `customItems` json DEFAULT NULL,
  `aiSuggestion` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `staffNotes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('draft','sent','accepted','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `sentAt` timestamp NULL DEFAULT NULL,
  `createdBy` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `idx_treatment_proposals_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=60001;

-- BASE TABLE: users
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `openId` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(320) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `loginMethod` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('patient','staff','doctor','admin','manager') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'patient',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `lastSignedIn` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `avatarUrl` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passwordHash` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  `status` enum('pending','active','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `firstName` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secondName` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thirdName` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `jobTitle` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `languages` json DEFAULT NULL,
  `weeklySchedule` json DEFAULT NULL,
  `slotDurationMinutes` int DEFAULT '30',
  `primaryLanguage` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `users_openId_unique` (`openId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=180001;

-- BASE TABLE: whatsapp_agent_runs
CREATE TABLE `whatsapp_agent_runs` (
  `messageId` int NOT NULL,
  `chatId` int NOT NULL,
  `state` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `leaseUntil` timestamp NULL DEFAULT NULL,
  `leaseToken` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempts` int NOT NULL DEFAULT '0',
  `reply` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modeVersion` int DEFAULT NULL,
  `documentId` int DEFAULT NULL,
  `taskId` int DEFAULT NULL,
  `provider` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `model` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `error` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`messageId`) /*T![clustered_index] CLUSTERED */,
  KEY `wa_agent_pending_ix` (`state`,`createdAt`),
  KEY `wa_agent_chat_ix` (`chatId`,`messageId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- BASE TABLE: whatsapp_allowed_chats
CREATE TABLE `whatsapp_allowed_chats` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lineId` int NOT NULL,
  `externalChatId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `addedById` int NOT NULL,
  `lastSyncedAt` timestamp NULL DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `leadId` int DEFAULT NULL,
  `patientId` int DEFAULT NULL,
  `aiMode` enum('AI_ACTIVE','HUMAN_REQUIRED','HUMAN_ACTIVE','PAUSED') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'AI_ACTIVE',
  `aiSummary` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aiError` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modeVersion` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_allowed_chats_line_chat_uq` (`lineId`,`externalChatId`),
  KEY `whatsapp_allowed_chats_line_enabled_ix` (`lineId`,`enabled`,`updatedAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=60001;

-- BASE TABLE: whatsapp_communication_endpoints
CREATE TABLE `whatsapp_communication_endpoints` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clinicScope` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fertiliv',
  `connectionId` int DEFAULT NULL,
  `connectionRoute` enum('legacy_env','persisted') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` enum('meta','wppconnect') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'meta',
  `providerPhoneNumberId` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerEndpointId` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `endpointKind` enum('phone') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'phone',
  `normalizedEndpointId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lifecycleState` enum('active','blocked') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `firstSeenAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastSeenAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_endpoints_provider_phone_endpoint_uq` (`provider`,`providerPhoneNumberId`,`providerEndpointId`),
  KEY `whatsapp_endpoints_normalized_endpoint_ix` (`provider`,`normalizedEndpointId`),
  KEY `whatsapp_endpoints_connection_ix` (`connectionId`,`lastSeenAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=660001;

-- BASE TABLE: whatsapp_connection_credentials
CREATE TABLE `whatsapp_connection_credentials` (
  `id` int NOT NULL AUTO_INCREMENT,
  `connectionId` int NOT NULL,
  `credentialKind` enum('business_access_token') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'business_access_token',
  `encryptedCredential` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `encryptionVersion` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'v1',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `lastValidatedAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_connection_credentials_connection_uq` (`connectionId`),
  KEY `whatsapp_connection_credentials_kind_ix` (`credentialKind`,`updatedAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- BASE TABLE: whatsapp_connection_transitions
CREATE TABLE `whatsapp_connection_transitions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `connectionId` int NOT NULL,
  `fromOnboardingMethod` enum('manual_cloud_api','meta_embedded_signup','meta_coexistence') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `toOnboardingMethod` enum('manual_cloud_api','meta_embedded_signup','meta_coexistence') COLLATE utf8mb4_unicode_ci NOT NULL,
  `fromCredentialSource` enum('legacy_env','secret_reference') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `toCredentialSource` enum('legacy_env','secret_reference') COLLATE utf8mb4_unicode_ci NOT NULL,
  `transitionReason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transitionedById` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `whatsapp_connection_transitions_connection_ix` (`connectionId`,`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- BASE TABLE: whatsapp_connections
CREATE TABLE `whatsapp_connections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clinicScope` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fertiliv',
  `provider` enum('meta','wppconnect') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'meta',
  `onboardingMethod` enum('manual_cloud_api','meta_embedded_signup','meta_coexistence','linked_device_wppconnect_sandbox','linked_device_wppconnect_server') COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerPhoneNumberId` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `wabaId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `businessPortfolioId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `displayPhone` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `normalizedDisplayPhone` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `displayName` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerMetadata` json DEFAULT NULL,
  `credentialSource` enum('legacy_env','secret_reference') COLLATE utf8mb4_unicode_ci NOT NULL,
  `credentialRef` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lifecycleStatus` enum('onboarding','connected','needs_attention','paused','disconnected','error') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'onboarding',
  `providerStateSnapshot` json DEFAULT NULL,
  `healthState` enum('unknown','healthy','degraded','unavailable') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unknown',
  `lastHealthCheckedAt` timestamp NULL DEFAULT NULL,
  `lastInboundEventAt` timestamp NULL DEFAULT NULL,
  `lastOutboundAcceptedAt` timestamp NULL DEFAULT NULL,
  `lastProviderStatusAt` timestamp NULL DEFAULT NULL,
  `lastTransitionAt` timestamp NULL DEFAULT NULL,
  `createdById` int DEFAULT NULL,
  `updatedById` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_connections_provider_phone_uq` (`provider`,`providerPhoneNumberId`),
  KEY `whatsapp_connections_waba_phone_ix` (`wabaId`,`providerPhoneNumberId`),
  KEY `whatsapp_connections_scope_display_phone_ix` (`clinicScope`,`normalizedDisplayPhone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=270001;

-- BASE TABLE: whatsapp_conversation_activities
CREATE TABLE `whatsapp_conversation_activities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `conversationId` int NOT NULL,
  `actorId` int NOT NULL,
  `action` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `summary` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  KEY `whatsapp_conversation_activities_conversation_ix` (`conversationId`,`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1890001;

-- BASE TABLE: whatsapp_conversation_assignments
CREATE TABLE `whatsapp_conversation_assignments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `conversationId` int NOT NULL,
  `assignedUserId` int DEFAULT NULL,
  `assignedById` int NOT NULL,
  `assignedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_conversation_assignments_conversation_uq` (`conversationId`),
  KEY `whatsapp_conversation_assignments_user_ix` (`assignedUserId`,`updatedAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=120001;

-- BASE TABLE: whatsapp_conversation_case_links
CREATE TABLE `whatsapp_conversation_case_links` (
  `id` int NOT NULL AUTO_INCREMENT,
  `conversationId` int NOT NULL,
  `caseId` int NOT NULL,
  `relationshipRole` enum('patient','husband','wife','representative','family','translator','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'other',
  `linkedById` int NOT NULL,
  `linkedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `retiredAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_conversation_case_links_active_uq` (`conversationId`,`caseId`,`relationshipRole`),
  KEY `whatsapp_conversation_case_links_conversation_ix` (`conversationId`,`retiredAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- BASE TABLE: whatsapp_conversation_match_suggestions
CREATE TABLE `whatsapp_conversation_match_suggestions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `conversationId` int NOT NULL,
  `endpointId` int DEFAULT NULL,
  `candidateType` enum('person','lead','patient') COLLATE utf8mb4_unicode_ci NOT NULL,
  `candidateId` int NOT NULL,
  `matchedField` enum('exact_phone','provider_hint') COLLATE utf8mb4_unicode_ci NOT NULL,
  `confidence` enum('high','medium') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'high',
  `state` enum('pending','accepted','dismissed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `reviewedById` int DEFAULT NULL,
  `reviewedAt` timestamp NULL DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_conversation_match_suggestions_uq` (`conversationId`,`candidateType`,`candidateId`),
  KEY `whatsapp_conversation_match_suggestions_state_ix` (`conversationId`,`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- BASE TABLE: whatsapp_conversation_messages
CREATE TABLE `whatsapp_conversation_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `conversationId` int NOT NULL,
  `sourceEventId` int NOT NULL,
  `normalizedMessageId` int NOT NULL,
  `resolutionId` int DEFAULT NULL,
  `provider` enum('meta','wppconnect') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'meta',
  `providerPhoneNumberId` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerMessageId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerItemKey` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `associationKey` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `correlationState` enum('correlated','quarantined') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'correlated',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_conversation_messages_association_uq` (`associationKey`),
  UNIQUE KEY `whatsapp_conversation_messages_normalized_message_uq` (`normalizedMessageId`),
  KEY `whatsapp_conversation_messages_conversation_ix` (`conversationId`,`createdAt`),
  KEY `whatsapp_conversation_messages_source_event_ix` (`sourceEventId`),
  KEY `whatsapp_conversation_messages_provider_message_ix` (`provider`,`providerMessageId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1170001;

-- BASE TABLE: whatsapp_conversation_participants
CREATE TABLE `whatsapp_conversation_participants` (
  `id` int NOT NULL AUTO_INCREMENT,
  `conversationId` int NOT NULL,
  `endpointId` int DEFAULT NULL,
  `personIdentityId` int DEFAULT NULL,
  `sourceResolutionId` int DEFAULT NULL,
  `participantKey` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `participantRole` enum('remote_endpoint','group_participant') COLLATE utf8mb4_unicode_ci NOT NULL,
  `participantState` enum('unresolved','candidate','confirmed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unresolved',
  `providerParticipantId` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerHintDigest` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `humanActorResolutionState` enum('unresolved','confirmed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unresolved',
  `medicalSubjectResolutionState` enum('unresolved') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unresolved',
  `firstSeenAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastSeenAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_conversation_participants_key_uq` (`participantKey`),
  KEY `whatsapp_conversation_participants_conversation_ix` (`conversationId`,`lastSeenAt`),
  KEY `whatsapp_conversation_participants_endpoint_ix` (`endpointId`,`lastSeenAt`),
  KEY `whatsapp_conversation_participants_person_ix` (`personIdentityId`,`lastSeenAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1320001;

-- BASE TABLE: whatsapp_conversation_read_states
CREATE TABLE `whatsapp_conversation_read_states` (
  `id` int NOT NULL AUTO_INCREMENT,
  `conversationId` int NOT NULL,
  `userId` int NOT NULL,
  `lastReadMessageId` int DEFAULT NULL,
  `readAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_conversation_read_states_conversation_user_uq` (`conversationId`,`userId`),
  KEY `whatsapp_conversation_read_states_user_ix` (`userId`,`updatedAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1740001;

-- BASE TABLE: whatsapp_conversation_tags
CREATE TABLE `whatsapp_conversation_tags` (
  `id` int NOT NULL AUTO_INCREMENT,
  `conversationId` int NOT NULL,
  `tag` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdById` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_conversation_tags_conversation_tag_uq` (`conversationId`,`tag`),
  KEY `whatsapp_conversation_tags_tag_ix` (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- BASE TABLE: whatsapp_conversations
CREATE TABLE `whatsapp_conversations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clinicScope` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fertiliv',
  `provider` enum('meta','wppconnect') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'meta',
  `connectionId` int DEFAULT NULL,
  `connectionRoute` enum('legacy_env','persisted') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerPhoneNumberId` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerThreadId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `conversationKey` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversationType` enum('private','group') COLLATE utf8mb4_unicode_ci NOT NULL,
  `identityBasis` enum('remote_endpoint','provider_thread') COLLATE utf8mb4_unicode_ci NOT NULL,
  `endpointResolutionState` enum('unresolved','candidate_single','candidate_multiple','confirmed') COLLATE utf8mb4_unicode_ci NOT NULL,
  `humanActorResolutionState` enum('unresolved','confirmed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unresolved',
  `medicalSubjectResolutionState` enum('unresolved') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unresolved',
  `lifecycleState` enum('active','archived') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `firstMessageAt` timestamp NULL DEFAULT NULL,
  `lastMessageAt` timestamp NULL DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_conversations_key_uq` (`conversationKey`),
  KEY `whatsapp_conversations_connection_time_ix` (`connectionId`,`lastMessageAt`),
  KEY `whatsapp_conversations_provider_thread_ix` (`provider`,`providerPhoneNumberId`,`providerThreadId`),
  KEY `whatsapp_conversations_type_state_ix` (`conversationType`,`lifecycleState`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1320001;

-- BASE TABLE: whatsapp_embedded_signup_sessions
CREATE TABLE `whatsapp_embedded_signup_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `requestId` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `startedById` int NOT NULL,
  `state` enum('started','cancelled','failed','completed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'started',
  `completionEvent` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `currentStep` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `failureCategory` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerWabaId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerPhoneNumberId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerBusinessPortfolioId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `connectionId` int DEFAULT NULL,
  `expiresAt` timestamp NOT NULL,
  `completedAt` timestamp NULL DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `authorizationCodeDigest` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_embedded_signup_sessions_request_uq` (`requestId`),
  KEY `whatsapp_embedded_signup_sessions_state_created_ix` (`state`,`createdAt`),
  KEY `whatsapp_embedded_signup_sessions_provider_identity_ix` (`providerWabaId`,`providerPhoneNumberId`),
  UNIQUE KEY `whatsapp_embedded_signup_sessions_code_digest_uq` (`authorizationCodeDigest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=90001;

-- BASE TABLE: whatsapp_endpoint_aliases
CREATE TABLE `whatsapp_endpoint_aliases` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clinicScope` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fertiliv',
  `provider` enum('meta','wppconnect') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'meta',
  `connectionId` int DEFAULT NULL,
  `providerPhoneNumberId` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerIdentityId` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `endpointId` int NOT NULL,
  `sourceEventId` int DEFAULT NULL,
  `aliasKind` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'provider_identity',
  `aliasState` enum('active','revoked') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `firstSeenAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastSeenAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_endpoint_aliases_identity_uq` (`provider`,`providerPhoneNumberId`,`providerIdentityId`),
  KEY `whatsapp_endpoint_aliases_endpoint_ix` (`endpointId`,`lastSeenAt`),
  KEY `whatsapp_endpoint_aliases_connection_ix` (`connectionId`,`lastSeenAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=870001;

-- BASE TABLE: whatsapp_endpoint_evidence_hints
CREATE TABLE `whatsapp_endpoint_evidence_hints` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sourceEventId` int NOT NULL,
  `resolutionId` int NOT NULL,
  `endpointId` int DEFAULT NULL,
  `hintType` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerHintValue` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerHintDigest` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `evidenceState` enum('provider_hint') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'provider_hint',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_endpoint_evidence_hints_uq` (`resolutionId`,`hintType`,`providerHintDigest`),
  KEY `whatsapp_endpoint_evidence_hints_endpoint_ix` (`endpointId`,`createdAt`),
  KEY `whatsapp_endpoint_evidence_hints_source_event_ix` (`sourceEventId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1170001;

-- BASE TABLE: whatsapp_endpoint_person_links
CREATE TABLE `whatsapp_endpoint_person_links` (
  `id` int NOT NULL AUTO_INCREMENT,
  `endpointId` int NOT NULL,
  `personIdentityId` int NOT NULL,
  `linkState` enum('confirmed','revoked') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'confirmed',
  `trustSource` enum('manual_confirmation','trusted_import') COLLATE utf8mb4_unicode_ci NOT NULL,
  `confirmedById` int DEFAULT NULL,
  `confirmedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `revokedAt` timestamp NULL DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_endpoint_person_links_endpoint_identity_uq` (`endpointId`,`personIdentityId`),
  KEY `whatsapp_endpoint_person_links_endpoint_state_ix` (`endpointId`,`linkState`),
  KEY `whatsapp_endpoint_person_links_identity_state_ix` (`personIdentityId`,`linkState`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- BASE TABLE: whatsapp_endpoint_resolution_candidates
CREATE TABLE `whatsapp_endpoint_resolution_candidates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `resolutionId` int NOT NULL,
  `recordType` enum('lead','patient') COLLATE utf8mb4_unicode_ci NOT NULL,
  `recordId` int NOT NULL,
  `matchedField` enum('phone','secondaryPhone') COLLATE utf8mb4_unicode_ci NOT NULL,
  `convertedPatientId` int DEFAULT NULL,
  `candidateKey` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_endpoint_resolution_candidates_key_uq` (`resolutionId`,`candidateKey`),
  KEY `whatsapp_endpoint_resolution_candidates_record_ix` (`recordType`,`recordId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- BASE TABLE: whatsapp_endpoint_resolutions
CREATE TABLE `whatsapp_endpoint_resolutions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sourceEventId` int NOT NULL,
  `provider` enum('meta','wppconnect') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'meta',
  `connectionId` int DEFAULT NULL,
  `connectionRoute` enum('legacy_env','persisted') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerPhoneNumberId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerEndpointId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerMessageId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `routingState` enum('legacy_env','resolved','unmapped','mismatched','unsupported') COLLATE utf8mb4_unicode_ci NOT NULL,
  `endpointId` int DEFAULT NULL,
  `resolutionKey` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resolutionState` enum('unresolved','candidate_single','candidate_multiple','confirmed') COLLATE utf8mb4_unicode_ci NOT NULL,
  `resolutionReason` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `confirmedPersonIdentityId` int DEFAULT NULL,
  `humanActorResolutionState` enum('unresolved','confirmed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unresolved',
  `medicalSubjectResolutionState` enum('unresolved') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unresolved',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_endpoint_resolutions_key_uq` (`resolutionKey`),
  KEY `whatsapp_endpoint_resolutions_source_event_ix` (`sourceEventId`),
  KEY `whatsapp_endpoint_resolutions_endpoint_ix` (`endpointId`,`createdAt`),
  KEY `whatsapp_endpoint_resolutions_state_ix` (`resolutionState`,`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1170001;

-- BASE TABLE: whatsapp_inbox_notification_preferences
CREATE TABLE `whatsapp_inbox_notification_preferences` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `notifyNewConversation` tinyint(1) NOT NULL DEFAULT '1',
  `notifyNewMessage` tinyint(1) NOT NULL DEFAULT '1',
  `notifyAssignment` tinyint(1) NOT NULL DEFAULT '1',
  `notifyHealth` tinyint(1) NOT NULL DEFAULT '1',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `userId` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=30001;

-- BASE TABLE: whatsapp_inbox_settings
CREATE TABLE `whatsapp_inbox_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clinicScope` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fertiliv',
  `phoneVisibility` enum('full_authorized','mask_selected_roles','admin_only_full') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'full_authorized',
  `newSenderBehavior` enum('conversation_only','create_contact','create_lead') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'conversation_only',
  `exactPhoneMatch` enum('suggest','auto_link_trusted','never_auto_link') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'never_auto_link',
  `duplicateDetection` enum('suggest','require_confirmation') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'require_confirmation',
  `caseSuggestions` tinyint(1) NOT NULL DEFAULT '0',
  `automaticPatient` tinyint(1) NOT NULL DEFAULT '0',
  `automaticMrn` tinyint(1) NOT NULL DEFAULT '0',
  `automaticClinicalRecord` tinyint(1) NOT NULL DEFAULT '0',
  `updatedById` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_inbox_settings_scope_uq` (`clinicScope`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=150001;

-- BASE TABLE: whatsapp_linked_device_credentials
CREATE TABLE `whatsapp_linked_device_credentials` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lineId` int NOT NULL,
  `credentialKind` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `encryptedCredential` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `encryptionVersion` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'v1',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `lastValidatedAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_linked_device_credentials_line_uq` (`lineId`),
  KEY `whatsapp_linked_device_credentials_kind_ix` (`credentialKind`,`updatedAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=240001;

-- BASE TABLE: whatsapp_linked_device_line_staff
CREATE TABLE `whatsapp_linked_device_line_staff` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lineId` int NOT NULL,
  `userId` int NOT NULL,
  `grantedById` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_linked_device_line_staff_uq` (`lineId`,`userId`),
  KEY `whatsapp_linked_device_line_staff_user_ix` (`userId`,`lineId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=450001;

-- BASE TABLE: whatsapp_linked_device_lines
CREATE TABLE `whatsapp_linked_device_lines` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clinicScope` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fertiliv',
  `lineName` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connectionId` int DEFAULT NULL,
  `providerApprovalState` enum('blocked','approved') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'blocked',
  `adapterKind` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unselected',
  `lifecycleState` enum('not_started','creating_session','waiting_for_qr','qr_ready','qr_expired','linking','connected','reconnecting','disconnected','logged_out','session_invalid','failed','disabled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'not_started',
  `healthState` enum('unknown','healthy','degraded','unavailable') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unknown',
  `displayPhone` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `normalizedDisplayPhone` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `connectedAt` timestamp NULL DEFAULT NULL,
  `lastSeenAt` timestamp NULL DEFAULT NULL,
  `lastSuccessfulSyncAt` timestamp NULL DEFAULT NULL,
  `disconnectedAt` timestamp NULL DEFAULT NULL,
  `createdById` int NOT NULL,
  `updatedById` int DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ownerUserId` int DEFAULT NULL,
  `ownerRole` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_linked_device_lines_scope_name_uq` (`clinicScope`,`lineName`),
  KEY `whatsapp_linked_device_lines_connection_ix` (`connectionId`),
  KEY `whatsapp_linked_device_lines_state_ix` (`lifecycleState`,`updatedAt`),
  KEY `whatsapp_linked_device_lines_owner_ix` (`ownerUserId`,`lifecycleState`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=390001;

-- BASE TABLE: whatsapp_linked_device_messages
CREATE TABLE `whatsapp_linked_device_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lineId` int NOT NULL,
  `allowedChatId` int NOT NULL,
  `ownerUserId` int NOT NULL,
  `externalMessageId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direction` enum('incoming','outgoing') COLLATE utf8mb4_unicode_ci NOT NULL,
  `messageType` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'chat',
  `text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mediaUrl` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mediaMetadata` json DEFAULT NULL,
  `sentByMe` tinyint(1) NOT NULL DEFAULT '0',
  `deliveryStatus` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `messageTimestamp` timestamp NOT NULL,
  `rawMetadata` json DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_linked_messages_line_external_uq` (`lineId`,`externalMessageId`),
  KEY `whatsapp_linked_messages_chat_time_ix` (`allowedChatId`,`messageTimestamp`),
  KEY `whatsapp_linked_messages_owner_time_ix` (`ownerUserId`,`messageTimestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=180001;

-- BASE TABLE: whatsapp_linked_device_sessions
CREATE TABLE `whatsapp_linked_device_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `lineId` int NOT NULL,
  `state` enum('not_started','creating_session','waiting_for_qr','qr_ready','qr_expired','linking','connected','reconnecting','disconnected','logged_out','session_invalid','failed','disabled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'not_started',
  `failureCategory` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastRequestedAt` timestamp NULL DEFAULT NULL,
  `lastStateChangedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `createdById` int NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sessionName` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerAccountHint` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerPushName` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerPlatform` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reconnectCount` int NOT NULL DEFAULT '0',
  `lastActivityAt` timestamp NULL DEFAULT NULL,
  `lastHealthCheckedAt` timestamp NULL DEFAULT NULL,
  `lastErrorCategory` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastErrorAt` timestamp NULL DEFAULT NULL,
  `runtimeSlot` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `runtimeEndpoint` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `runtimeMode` enum('sandbox','persistent_worker') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `runtimeGeneration` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `runtimeProfileRef` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `runtimeAllocatedAt` timestamp NULL DEFAULT NULL,
  `runtimeReleasedAt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_linked_device_sessions_line_uq` (`lineId`),
  KEY `whatsapp_linked_device_sessions_state_ix` (`state`,`updatedAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=420001;

-- BASE TABLE: whatsapp_messages
CREATE TABLE `whatsapp_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fromPhone` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `toPhone` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direction` enum('inbound','outbound') COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('received','sent','delivered','read','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'received',
  `leadId` int DEFAULT NULL,
  `patientId` int DEFAULT NULL,
  `externalMessageId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `templateName` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sentById` int DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=270001;

-- BASE TABLE: whatsapp_normalized_media
CREATE TABLE `whatsapp_normalized_media` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sourceEventId` int NOT NULL,
  `connectionId` int DEFAULT NULL,
  `connectionRoute` enum('legacy_env','persisted') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` enum('meta','wppconnect') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'meta',
  `wabaId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerPhoneNumberId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sourceMessageItemKey` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerMediaItemKey` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerMediaId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mediaType` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mimeType` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sha256` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filename` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caption` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mediaState` enum('metadata_only','quarantined') COLLATE utf8mb4_unicode_ci NOT NULL,
  `failureCategory` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_normalized_media_provider_item_uq` (`provider`,`providerMediaItemKey`),
  KEY `whatsapp_normalized_media_source_event_ix` (`sourceEventId`),
  KEY `whatsapp_normalized_media_provider_id_ix` (`provider`,`providerMediaId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=480001;

-- BASE TABLE: whatsapp_normalized_messages
CREATE TABLE `whatsapp_normalized_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sourceEventId` int NOT NULL,
  `connectionId` int DEFAULT NULL,
  `connectionRoute` enum('legacy_env','persisted') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` enum('meta','wppconnect') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'meta',
  `wabaId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerPhoneNumberId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerMessageId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerItemKey` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerSenderId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerRecipientId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerTimestamp` timestamp NULL DEFAULT NULL,
  `providerDirection` enum('inbound','outbound_echo','unknown') COLLATE utf8mb4_unicode_ci NOT NULL,
  `messageType` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `textBody` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `normalizedContent` json DEFAULT NULL,
  `normalizationVersion` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `normalizationState` enum('normalized','quarantined') COLLATE utf8mb4_unicode_ci NOT NULL,
  `failureCategory` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_normalized_messages_provider_item_uq` (`provider`,`providerItemKey`),
  KEY `whatsapp_normalized_messages_source_event_ix` (`sourceEventId`),
  KEY `whatsapp_normalized_messages_provider_message_ix` (`provider`,`providerMessageId`),
  KEY `whatsapp_normalized_messages_connection_time_ix` (`connectionId`,`providerTimestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1170001;

-- BASE TABLE: whatsapp_normalized_statuses
CREATE TABLE `whatsapp_normalized_statuses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sourceEventId` int NOT NULL,
  `connectionId` int DEFAULT NULL,
  `connectionRoute` enum('legacy_env','persisted') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` enum('meta','wppconnect') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'meta',
  `wabaId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerPhoneNumberId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerStatusId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerStatusKey` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerMessageId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerRecipientId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerTimestamp` timestamp NULL DEFAULT NULL,
  `statusValue` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `errorCode` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `errorTitle` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `normalizationVersion` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `normalizationState` enum('normalized','quarantined') COLLATE utf8mb4_unicode_ci NOT NULL,
  `failureCategory` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_normalized_statuses_provider_key_uq` (`provider`,`providerStatusKey`),
  KEY `whatsapp_normalized_statuses_source_event_ix` (`sourceEventId`),
  KEY `whatsapp_normalized_statuses_provider_message_ix` (`provider`,`providerMessageId`),
  KEY `whatsapp_normalized_statuses_connection_time_ix` (`connectionId`,`providerTimestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- BASE TABLE: whatsapp_person_identities
CREATE TABLE `whatsapp_person_identities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clinicScope` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fertiliv',
  `identityKind` enum('human') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'human',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- BASE TABLE: whatsapp_person_identity_records
CREATE TABLE `whatsapp_person_identity_records` (
  `id` int NOT NULL AUTO_INCREMENT,
  `personIdentityId` int NOT NULL,
  `recordType` enum('lead','patient') COLLATE utf8mb4_unicode_ci NOT NULL,
  `recordId` int NOT NULL,
  `relationshipState` enum('active','retired') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `trustSource` enum('manual_confirmation','trusted_import') COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_person_identity_records_identity_record_uq` (`personIdentityId`,`recordType`,`recordId`),
  KEY `whatsapp_person_identity_records_record_ix` (`recordType`,`recordId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- BASE TABLE: whatsapp_phone_identities
CREATE TABLE `whatsapp_phone_identities` (
  `phone` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `leadId` int DEFAULT NULL,
  `patientId` int DEFAULT NULL,
  PRIMARY KEY (`phone`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- BASE TABLE: whatsapp_provider_event_batches
CREATE TABLE `whatsapp_provider_event_batches` (
  `id` int NOT NULL AUTO_INCREMENT,
  `provider` enum('meta','wppconnect') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'meta',
  `rawPayloadDigest` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rawPayload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `signatureValid` tinyint(1) NOT NULL DEFAULT '0',
  `receivedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastReceivedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_provider_event_batches_payload_uq` (`provider`,`rawPayloadDigest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1200001;

-- BASE TABLE: whatsapp_provider_events
CREATE TABLE `whatsapp_provider_events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `batchId` int NOT NULL,
  `connectionId` int DEFAULT NULL,
  `connectionRoute` enum('legacy_env','persisted') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` enum('meta','wppconnect') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'meta',
  `wabaId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerPhoneNumberId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `providerField` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerEventKey` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `routingState` enum('legacy_env','resolved','unmapped','mismatched','unsupported') COLLATE utf8mb4_unicode_ci NOT NULL,
  `processingState` enum('received','processing','applied','quarantined','failed','dead_letter') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'received',
  `failureCategory` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receivedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `processedAt` timestamp NULL DEFAULT NULL,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_provider_events_provider_key_uq` (`provider`,`providerEventKey`),
  KEY `whatsapp_provider_events_state_received_ix` (`processingState`,`receivedAt`),
  KEY `whatsapp_provider_events_connection_received_ix` (`connectionId`,`receivedAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1200001;

-- BASE TABLE: whatsapp_sales_knowledge
CREATE TABLE `whatsapp_sales_knowledge` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `updatedBy` int DEFAULT NULL,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- BASE TABLE: whatsapp_send_attempts
CREATE TABLE `whatsapp_send_attempts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `conversationId` int DEFAULT NULL,
  `connectionId` int DEFAULT NULL,
  `connectionRoute` enum('legacy_env','persisted') COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider` enum('meta','wppconnect') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'meta',
  `providerPhoneNumberId` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actorUserId` int DEFAULT NULL,
  `recipientEndpoint` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `intentType` enum('text','template','document') COLLATE utf8mb4_unicode_ci NOT NULL,
  `payloadDigest` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idempotencyKey` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attemptState` enum('pending','submitting','accepted','delivered','read','failed','ambiguous','requires_retry') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `providerMessageId` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `failureCategory` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `acceptedAt` timestamp NULL DEFAULT NULL,
  `completedAt` timestamp NULL DEFAULT NULL,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `clientActionId` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diagnosticStage` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diagnosticProbe` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diagnosticOutcome` varchar(96) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `diagnosticAt` timestamp NULL DEFAULT NULL,
  `correlationId` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lineId` int DEFAULT NULL,
  `sessionName` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `runtimeEndpointHost` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `runtimeMode` enum('sandbox','persistent_worker') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `runtimeGateValue` tinyint(1) DEFAULT NULL,
  `approvalSecretSelector` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approvalProofVersion` int DEFAULT NULL,
  `approvalExpiryState` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recipientFingerprint` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approvalReason` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_send_attempts_idempotency_uq` (`idempotencyKey`),
  KEY `whatsapp_send_attempts_provider_message_ix` (`provider`,`providerMessageId`),
  KEY `whatsapp_send_attempts_connection_created_ix` (`connectionId`,`createdAt`),
  KEY `whatsapp_send_attempts_conversation_ix` (`conversationId`,`createdAt`),
  KEY `whatsapp_send_attempts_client_action_ix` (`clientActionId`,`createdAt`),
  KEY `whatsapp_send_attempts_correlation_ix` (`correlationId`,`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=750001;

-- BASE TABLE: whatsapp_synthetic_test_recipients
CREATE TABLE `whatsapp_synthetic_test_recipients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clinicScope` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fertiliv',
  `lineId` int NOT NULL,
  `normalizedPhone` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','revoked') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `approvedById` int NOT NULL,
  `approvedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `revokedById` int DEFAULT NULL,
  `revokedAt` timestamp NULL DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) /*T![clustered_index] CLUSTERED */,
  UNIQUE KEY `whatsapp_synthetic_test_recipients_line_phone_uq` (`lineId`,`normalizedPhone`),
  KEY `whatsapp_synthetic_test_recipients_line_status_ix` (`lineId`,`status`,`updatedAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=210001;

SET FOREIGN_KEY_CHECKS=1;
