# تقرير تسليم — نسخة بيانات Fertiliv Production إلى MySQL 8.4

**وقت الالتقاط (UTC):** 2026-09-30T19:46:11.585Z  
**نوع العملية:** COPY / read-only export فقط  
**المصدر:** Fertiliv production TiDB Serverless (MySQL-compatible)  
**لا يحتوي هذا التقرير أو الحزمة على:** `DATABASE_URL` أو كلمات مرور أو متغيرات البيئة أو مفاتيح API أو ملفات profiles/QR أو جلسات WhatsApp الحية.

## 1. المشكلة/الطلب المرصود

المطلوب هو إخراج نسخة محمولة من **المخطط الفعلي الحالي وبيانات التطبيق الحالية** إلى MySQL 8.4 مستقل على Windows، من دون الاعتماد على Drizzle migrations، ودون تغيير production أو نقل WhatsApp sessions/provider runtime.

**التصنيف:** database/export/infrastructure. لم يكن هناك عطل production.

## 2. السبب التقني

سجل Drizzle المطبق في production لا يعكس تاريخ المخطط كاملاً؛ لذلك لا يصلح كوسيلة إعادة بناء. مصدر الحقيقة لهذه الحزمة هو:

- `SHOW CREATE TABLE` لكل جدول فعلي.
- `information_schema` للأعمدة والفهارس والقيود والـcollation/defaults.
- قراءة صفوف البيانات مباشرة من جداول production عبر اتصال TLS read-only عملياً (عمليات SELECT/SHOW فقط).

## 3. ما تم إنشاؤه

| ملف | الغرض |
|---|---|
| `schema-raw-tidb.sql` | DDL خام من TiDB كما هو، لكل الجداول |
| `schema-mysql84-candidate.sql` | DDL مرشح لـMySQL 8.4؛ الفرق الوحيد الآلي هو إزالة 137 تعليق TiDB optimizer من نوع `clustered_index` |
| `data.sql` | SQL INSERT للبيانات القابلة للنقل |
| `schema-manifest.json` | أعمدة/defaults/types/charset/collation/indexes/constraints وrow counts |
| `table-row-counts.csv` | صفوف المصدر لكل جدول |
| `indexes-constraints.csv` | فهارس وقيود schema الحالية |
| `excluded-whatsapp-runtime-data.csv` | الجداول والصفوف المستبعدة صراحةً من data import |
| `file-object-references.csv` | جرد row-level لمفاتيح ومسارات الملفات المخزنة في DB |
| `file-object-reference-summary.csv` | summary لجرد الملفات دون الحاجة إلى تحليل SQL |
| `mysql84-compatibility-report.md` | ملاحظات TiDB → MySQL 8.4 والتحويلات المعلنة |
| `export-summary.json` | أرقام الحزمة وSHA-256 للملفات |
| `IMPORT-README.md` | ترتيب import المقترح إلى MySQL 8.4 |

لا توجد migrations، ولا schema mutation، ولا data mutation، ولا نشر، ولا تغيير في DNS أو تطبيق Fertiliv.

## 4. لماذا هذا التصميم

اختير `SHOW CREATE` و`information_schema` بدلاً من Drizzle migration replay لأنه يحافظ على المخطط الفعلي: IDs، primary keys، auto-increment counters، indexes، defaults، JSON، timestamps، enums، charset/collation والـforeign keys الموجودة.

المخطط الخام محفوظ دائماً كمرجع. ملف MySQL candidate منفصل وواضح ولا يحل محل المصدر الصريح؛ لا توجد transformations مخفية.

## 5. أثر السلامة

- لم يتم تنفيذ أي `INSERT` أو `UPDATE` أو `DELETE` أو migration أو lock أو freeze على production.
- لا يوجد تغيير في `pro.fertiliv.com` أو workers أو Google Calendar أو Email أو Meta أو WPPConnect Server أو 8899/8900.
- تم استبعاد **42 صفاً** من البيانات الحية الخاصة بتهيئة/جلسات/اعتمادات WhatsApp، تنفيذاً لشرط عدم ترحيل provider runtime:
  - `whatsapp_connections`: 12
  - `whatsapp_connection_credentials`: 0
  - `whatsapp_embedded_signup_sessions`: 3
  - `whatsapp_linked_device_lines`: 18
  - `whatsapp_linked_device_credentials`: 7
  - `whatsapp_linked_device_sessions`: 2
- schema لهذه الجداول محفوظ، لكن `data.sql` لا يحتوي INSERT لها.
- لم تُنسخ WhatsApp profiles أو QR payloads أو tokens أو encrypted provider credentials.

## 6. مخاطر الانحدار

هذه الحزمة ليست تغييراً لتطبيق production، ولذلك لا يوجد regression runtime متوقع على Fertiliv الحالي.

لكن عند الاستيراد إلى MySQL 8.4 يجب عدم تشغيل التطبيق أو workers أو outbound integrations قبل مقارنة schema/rows واعتماد البيئة. تطبيق Windows يحتاج secrets/configuration مستقلة ولا يستمد أي اعتماد من الحزمة.

## 7. التحقق المنفذ

| فحص | النتيجة |
|---|---|
| جداول المصدر | 137 table، 137 base table، لا views |
| صفوف المصدر | 29,016 |
| صفوف `data.sql` القابلة للاستيراد | 28,974 |
| WhatsApp runtime rows المستبعدة | 42 |
| فهارس/قيود | مسجلة في `indexes-constraints.csv` و`schema-manifest.json` |
| Triggers/Routines/Events | 0 / 0 / 0 في source schema |
| DDL raw | 137 `CREATE TABLE` |
| DDL MySQL candidate | أزيلت 137 تعليقات TiDB clustered-index؛ لا TiDB table options ظاهرة من القائمة المحافظة |
| charset/collation | `utf8mb4` مع `utf8mb4_unicode_ci` وموضع واحد `utf8mb4_bin` محفوظان |
| فحص تسرب ENV/connection URL/private key/JWT | لم تظهر الأنماط المفحوصة |
| استبعاد data runtime | لا توجد INSERT statements للجداول الستة المستبعدة |
| checksums | SHA-256 لكل ملف موجود في `export-summary.json` |

**لم يتم** إجراء import فعلي إلى MySQL 8.4 في هذه المهمة، لذلك قبول الاستيراد live هو NOT TESTED.

## 8. القيود المتبقية

1. لا يمكن إثبات أن كل object key يشير إلى R2 أو Forge من DB وحدها؛ المفاتيح العارية تصنف `storage_key_or_path` حتى يتم تنفيذ object-level audit منفصل.
2. لم يتم نسخ أو تنزيل أي file object من R2 أو Manus Forge. هذه الحزمة DB/reference inventory فقط.
3. `schema-mysql84-candidate.sql` يحتاج اختباراً في MySQL 8.4 disposable قبل اعتباره production-ready.
4. ترتيب foreign key في DDL محفوظ كما يعرض TiDB. الحزمة تضبط `FOREIGN_KEY_CHECKS=0` عند schema/data import ثم تعيد تفعيله؛ يجب مراجعة نتيجة constraints بعد الاستيراد.
5. DDL يحتوي `AUTO_INCREMENT` values كبيرة ومقصودة؛ لا تعيد تعيينها.

## 9. الحالة النهائية

- نسخة DB قابلة للاستيراد مبدئياً إلى MySQL 8.4 موجودة ومتحقق من files/checksums.
- مخطط production الفعلي محفوظ كـraw DDL، وليس مبنياً من Drizzle migrations.
- بيانات التطبيق الأساسية، CRM، patients، health records، treatment، finance، tasks، dictionaries، audit وcommunication metadata مدرجة.
- WhatsApp runtime/credential/session data مستبعدة عمداً، ولا يوجد provider session قابل للاستعادة من الحزمة.
- production بقي عاملاً دون تغيير.

## 10. مرجع التنفيذ

- **Export timestamp:** 2026-09-30T19:46:11.585Z UTC
- **Application checkpoint visible during export:** `92daf67f` (documentation checkpoint؛ لم يتم نشره أو تغييره ضمن عملية التصدير)
- **Publish:** لم يحدث.
- **Database/schema/runtime/session/provider change:** لم يحدث.
- **الخطوة التالية المطلوبة:** استيراد مرشح فقط إلى MySQL 8.4 disposable على Windows، ثم مقارنة manifests/row counts ونتيجة `information_schema` قبل تشغيل التطبيق أو تكوين أي integration.
