# Fertiliv production database copy

- Exported UTC: 2026-09-30T19:46:11.585Z
- Source engine: TiDB Serverless / MySQL-compatible
- This package is a **copy only**. It does not contain provider sessions, WhatsApp profiles, QR data, or environment secrets.
- Review mysql84-compatibility-report.md before importing into MySQL 8.4.

## Import order in a disposable MySQL 8.4 target

1. Create an empty target database with utf8mb4 and the intended collation.
2. Review and, if required, edit a copy of schema-mysql84-candidate.sql; preserve schema-raw-tidb.sql as the authoritative source DDL.
3. Import schema: mysql --default-character-set=utf8mb4 -u USER -p TARGET_DB < schema-mysql84-candidate.sql.
4. Import data: mysql --default-character-set=utf8mb4 -u USER -p TARGET_DB < data.sql.
5. Compare table-row-counts.csv, indexes-constraints.csv, and target information_schema before enabling application traffic.
6. Validate JSON, timestamps, generated/default values, foreign keys, and application smoke tests.

This README intentionally does not contain credentials, DATABASE_URL, provider state, or secrets.
